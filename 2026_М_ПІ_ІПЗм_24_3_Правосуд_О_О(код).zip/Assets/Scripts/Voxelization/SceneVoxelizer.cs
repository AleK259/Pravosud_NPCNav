using System.Collections.Generic;
using UnityEngine;

namespace Navigation.Voxelization
{
    /// <summary>
    /// Unity-компонент для вокселізації сцени.
    /// Прикріплюється до порожнього GameObject у сцені.
    /// 
    /// Забезпечує:
    /// - Налаштування параметрів через Inspector
    /// - Побудову октодерева при старті або за запитом
    /// - Візуалізацію через Gizmos (для дебагу та скріншотів у роботу)
    /// - Публічний доступ до побудованого дерева для інших підсистем
    /// </summary>
    public class SceneVoxelizer : MonoBehaviour
    {
        // =====================================================================
        //  НАЛАШТУВАННЯ В INSPECTOR
        // =====================================================================

        [Header("Розміри області сканування")]
        [Tooltip("Розмір сторони куба сканування (у метрах). " +
                  "Повинен охоплювати весь ігровий рівень.")]
        [SerializeField] private float worldSize = 64f;

        [Tooltip("Чи використовувати позицію цього об'єкта як центр, " +
                  "чи задати вручну.")]
        [SerializeField] private bool useTransformAsCenter = true;

        [Tooltip("Центр області сканування (якщо useTransformAsCenter = false).")]
        [SerializeField] private Vector3 customCenter = Vector3.zero;

        [Header("Параметри октодерева")]
        [Tooltip("Максимальна глибина рекурсії. " +
                  "6 = грубо (~1м), 7 = середньо (~0.5м), 8 = точно (~0.25м). " +
                  "Більше = повільніше побудова та більше пам'яті.")]
        [Range(4, 9)]
        [SerializeField] private int maxDepth = 7;

        [Tooltip("Максимальний кут нахилу поверхні для прохідності (градуси).")]
        [Range(10f, 60f)]
        [SerializeField] private float maxWalkableAngle = 45f;

        [Header("Шари та теги")]
        [Tooltip("Шари, які враховуються як геометрія (перешкоди та поверхні).")]
        [SerializeField] private LayerMask obstacleLayers = ~0;

        [Tooltip("Тег небезпечних зон.")]
        [SerializeField] private string dangerTag = "Danger";

        [Tooltip("Тег прохідних поверхонь.")]
        [SerializeField] private string groundTag = "Ground";

        [Header("Побудова")]
        [Tooltip("Автоматично будувати октодерево при Start().")]
        [SerializeField] private bool buildOnStart = true;

        [Tooltip("Затримка перед побудовою (секунди). " +
                  "Дає час фізичному рушію ініціалізуватися.")]
        [SerializeField] private float buildDelay = 0.1f;

        [Header("Візуалізація (Gizmos)")]
        [SerializeField] private bool showGizmos = true;
        [SerializeField] private bool showEmptyVoxels = false;
        [SerializeField] private bool showSolidVoxels = true;
        [SerializeField] private bool showGroundVoxels = true;
        [SerializeField] private bool showDangerVoxels = true;
        [SerializeField] private bool showOnlyLeaves = true;

        [Tooltip("Максимальна глибина для відображення Gizmos. " +
                  "Зменшіть, якщо редактор гальмує.")]
        [Range(1, 9)]
        [SerializeField] private int gizmoMaxDepth = 6;

        [Header("Кольори візуалізації")]
        [SerializeField] private Color emptyColor = new Color(0.5f, 0.5f, 1f, 0.05f);
        [SerializeField] private Color solidColor = new Color(0.5f, 0.5f, 0.5f, 0.2f);
        [SerializeField] private Color groundColor = new Color(0f, 1f, 0f, 0.4f);
        [SerializeField] private Color dangerColor = new Color(1f, 0f, 0f, 0.5f);
        [SerializeField] private Color boundsColor = new Color(1f, 1f, 0f, 0.3f);

        // =====================================================================
        //  ПУБЛІЧНИЙ ДОСТУП
        // =====================================================================

        /// <summary>Побудований OctreeBuilder з доступом до дерева та запитів.</summary>
        public OctreeBuilder Octree { get; private set; }

        /// <summary>Чи завершена побудова октодерева.</summary>
        public bool IsBuilt { get; private set; }

        /// <summary>Центр області сканування.</summary>
        public Vector3 WorldCenter =>
            useTransformAsCenter ? transform.position : customCenter;

        /// <summary>Розмір світу.</summary>
        public float WorldSize => worldSize;

        // =====================================================================
        //  UNITY LIFECYCLE
        // =====================================================================

        private void Start()
        {
            if (buildOnStart)
            {
                if (buildDelay > 0f)
                    Invoke(nameof(BuildOctree), buildDelay);
                else
                    BuildOctree();
            }
        }

        // =====================================================================
        //  ПОБУДОВА
        // =====================================================================

        /// <summary>
        /// Запускає побудову октодерева. Можна викликати ззовні
        /// або через кнопку в Inspector (через контекстне меню).
        /// </summary>
        [ContextMenu("Побудувати октодерево")]
        public void BuildOctree()
        {
            IsBuilt = false;

            Octree = new OctreeBuilder
            {
                MaxDepth = maxDepth,
                ObstacleLayerMask = obstacleLayers,
                DangerTag = dangerTag,
                GroundTag = groundTag,
                MaxWalkableAngle = maxWalkableAngle
            };

            Octree.Build(WorldCenter, worldSize);
            IsBuilt = true;

            Debug.Log($"[SceneVoxelizer] Октодерево побудовано. " +
                      $"Ground-вокселів для навігації: {Octree.GroundVoxels.Count}");
        }

        /// <summary>
        /// Перебудовує октодерево. Викликається при зміні геометрії сцени.
        /// </summary>
        [ContextMenu("Перебудувати октодерево")]
        public void RebuildOctree()
        {
            Debug.Log("[SceneVoxelizer] Перебудова октодерева...");
            BuildOctree();
        }

        // =====================================================================
        //  ПУБЛІЧНІ ЗАПИТИ (делегування до OctreeBuilder)
        // =====================================================================

        /// <summary>Знаходить воксель у заданій точці.</summary>
        public VoxelNode GetVoxelAt(Vector3 worldPosition)
        {
            if (!IsBuilt) return null;
            return Octree.QueryPoint(worldPosition);
        }

        /// <summary>Перевіряє, чи заблокована точка.</summary>
        public bool IsBlocked(Vector3 worldPosition)
        {
            if (!IsBuilt) return true;
            return Octree.IsPointBlocked(worldPosition);
        }

        /// <summary>Повертає словник усіх Ground-вокселів.</summary>
        public Dictionary<uint, VoxelNode> GetGroundVoxels()
        {
            if (!IsBuilt) return new Dictionary<uint, VoxelNode>();
            return Octree.GroundVoxels;
        }

        // =====================================================================
        //  ВІЗУАЛІЗАЦІЯ GIZMOS
        // =====================================================================

        private void OnDrawGizmosSelected()
        {
            // Завжди показуємо межі області сканування
            Gizmos.color = boundsColor;
            Gizmos.DrawWireCube(WorldCenter, Vector3.one * worldSize);

            if (!showGizmos || !IsBuilt || Octree?.Root == null) return;

            DrawNodeGizmos(Octree.Root);
        }

        /// <summary>
        /// Рекурсивно відмальовує вузли дерева як напівпрозорі куби.
        /// Різні кольори для різних типів вокселів.
        /// </summary>
        private void DrawNodeGizmos(VoxelNode node)
        {
            if (node == null) return;

            // Обмежуємо глибину відображення для продуктивності
            if (node.Depth > gizmoMaxDepth) return;

            if (node.IsLeaf)
            {
                bool shouldDraw = false;
                Color color = Color.clear;

                switch (node.Type)
                {
                    case VoxelType.Empty:
                        shouldDraw = showEmptyVoxels;
                        color = emptyColor;
                        break;
                    case VoxelType.Solid:
                        shouldDraw = showSolidVoxels;
                        color = solidColor;
                        break;
                    case VoxelType.Ground:
                        shouldDraw = showGroundVoxels;
                        color = groundColor;
                        break;
                    case VoxelType.Danger:
                        shouldDraw = showDangerVoxels;
                        color = dangerColor;
                        break;
                }

                if (shouldDraw)
                {
                    Gizmos.color = color;
                    Gizmos.DrawCube(node.Center, Vector3.one * node.Size * 0.95f);

                    // Контури для Ground-вокселів — краще видно
                    if (node.Type == VoxelType.Ground)
                    {
                        Gizmos.color = new Color(0f, 0.8f, 0f, 0.8f);
                        Gizmos.DrawWireCube(node.Center, Vector3.one * node.Size);
                    }
                }
            }
            else if (!showOnlyLeaves)
            {
                // Показуємо контури нелисткових вузлів (для розуміння структури дерева)
                Gizmos.color = new Color(1f, 1f, 1f, 0.05f);
                Gizmos.DrawWireCube(node.Center, Vector3.one * node.Size);
            }

            // Рекурсія у дочірні вузли
            if (!node.IsLeaf && node.Children != null)
            {
                for (int i = 0; i < 8; i++)
                {
                    DrawNodeGizmos(node.Children[i]);
                }
            }
        }

        // =====================================================================
        //  СТАТИСТИКА (для звіту та дебагу)
        // =====================================================================

        /// <summary>
        /// Виводить детальну статистику побудованого дерева у консоль.
        /// </summary>
        [ContextMenu("Показати статистику")]
        public void PrintStatistics()
        {
            if (!IsBuilt)
            {
                Debug.LogWarning("[SceneVoxelizer] Октодерево ще не побудовано.");
                return;
            }

            // Підраховуємо вузли за типами
            List<VoxelNode> allLeaves = Octree.GetAllLeaves();
            int emptyCount = 0, solidCount = 0, groundCount = 0, dangerCount = 0;

            foreach (VoxelNode leaf in allLeaves)
            {
                switch (leaf.Type)
                {
                    case VoxelType.Empty:  emptyCount++;  break;
                    case VoxelType.Solid:  solidCount++;  break;
                    case VoxelType.Ground: groundCount++; break;
                    case VoxelType.Danger: dangerCount++; break;
                }
            }

            // Оцінка пам'яті (приблизна)
            // VoxelNode ≈ 80-100 байт (Vector3 + float + refs + enums + ...)
            long estimatedMemoryBytes = (long)Octree.TotalNodeCount * 100;
            float estimatedMemoryMB = estimatedMemoryBytes / (1024f * 1024f);

            // Порівняння з повною сіткою
            int fullGridSize = Mathf.RoundToInt(Mathf.Pow(2, maxDepth));
            long fullGridNodes = (long)fullGridSize * fullGridSize * fullGridSize;
            float compressionRatio = (float)fullGridNodes / Octree.TotalNodeCount;

            Debug.Log(
                $"=== СТАТИСТИКА ОКТОДЕРЕВА ===\n" +
                $"Розмір світу: {worldSize}м, Глибина: {maxDepth}, Розмір листка: {Octree.LeafSize:F3}м\n" +
                $"Усього вузлів: {Octree.TotalNodeCount}\n" +
                $"Листків: {Octree.LeafNodeCount}\n" +
                $"  - Empty: {emptyCount}\n" +
                $"  - Solid: {solidCount}\n" +
                $"  - Ground (навігаційних): {groundCount}\n" +
                $"  - Danger: {dangerCount}\n" +
                $"Оцінка пам'яті: ~{estimatedMemoryMB:F2} МБ\n" +
                $"Повна сітка була б: {fullGridNodes:N0} вузлів\n" +
                $"Стиснення (SVO): {compressionRatio:F1}x"
            );
        }
    }
}
