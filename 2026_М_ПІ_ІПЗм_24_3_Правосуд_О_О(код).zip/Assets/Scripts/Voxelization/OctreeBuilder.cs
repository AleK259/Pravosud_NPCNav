using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;
using Debug = UnityEngine.Debug;

namespace Navigation.Voxelization
{
    /// <summary>
    /// Будівник розрідженого воксельного октодерева (Sparse Voxel Octree).
    /// 
    /// Алгоритм:
    /// 1. Кореневий вузол охоплює весь ігровий світ (куб).
    /// 2. Рекурсивно ділить простір на 8 октантів.
    /// 3. Якщо область однорідна (повністю порожня або суцільна) — зупиняє поділ.
    /// 4. Продовжує поділ до maxDepth лише в неоднорідних областях.
    /// 5. Після побудови класифікує листки (Ground, Danger, тощо).
    /// 
    /// Це забезпечує розрідженість: великі порожні/суцільні простори
    /// представлені одним вузлом, деталізація тільки біля поверхонь.
    /// </summary>
    public class OctreeBuilder
    {
        // --- Налаштування побудови ---

        /// <summary>
        /// Максимальна глибина рекурсії. Визначає роздільну здатність.
        /// depth=6 → мінімальний воксель = worldSize / 2^6 = worldSize / 64.
        /// Для світу 64м це ~1м, для depth=8 це ~0.25м.
        /// </summary>
        public int MaxDepth { get; set; } = 7;

        /// <summary>
        /// Маска шарів (Layer Mask), які вважаються перешкодами.
        /// Налаштуй у інспекторі Unity (зазвичай "Default" + "Ground").
        /// </summary>
        public LayerMask ObstacleLayerMask { get; set; } = ~0; // Усі шари за замовчуванням

        /// <summary>
        /// Тег для небезпечних зон (лава, кислота, прірви).
        /// Об'єкти з цим тегом позначаються як VoxelType.Danger.
        /// </summary>
        public string DangerTag { get; set; } = "Danger";

        /// <summary>
        /// Тег для поверхонь, по яких можна ходити.
        /// </summary>
        public string GroundTag { get; set; } = "Ground";

        /// <summary>
        /// Максимальний кут нахилу поверхні (у градусах),
        /// на якій агент може стояти. Відповідає αmax з постановки задачі.
        /// </summary>
        public float MaxWalkableAngle { get; set; } = 45f;

        /// <summary>
        /// Невелике розширення перевірки OverlapBox для уникнення
        /// граничних випадків (коли геометрія точно збігається з межею вокселя).
        /// </summary>
        private const float OVERLAP_EPSILON = 0.01f;

        // --- Результати побудови ---

        /// <summary>Кореневий вузол побудованого октодерева.</summary>
        public VoxelNode Root { get; private set; }

        /// <summary>Розмір найменшого вокселя (листка на максимальній глибині).</summary>
        public float LeafSize { get; private set; }

        /// <summary>Початок координат октодерева (мінімальний кут).</summary>
        public Vector3 Origin { get; private set; }

        /// <summary>Загальна кількість вузлів у дереві.</summary>
        public int TotalNodeCount { get; private set; }

        /// <summary>Кількість листкових вузлів.</summary>
        public int LeafNodeCount { get; private set; }

        /// <summary>
        /// Словник усіх Ground-вокселів (прохідних поверхонь).
        /// Ключ — код Мортона. Використовується як навігаційний граф.
        /// </summary>
        public Dictionary<uint, VoxelNode> GroundVoxels { get; private set; }

        // =====================================================================
        //  ОСНОВНИЙ МЕТОД ПОБУДОВИ
        // =====================================================================

        /// <summary>
        /// Будує октодерево для заданої кубічної області простору.
        /// </summary>
        /// <param name="worldCenter">Центр області сканування</param>
        /// <param name="worldSize">Розмір сторони куба</param>
        /// <returns>Кореневий вузол побудованого дерева</returns>
        public VoxelNode Build(Vector3 worldCenter, float worldSize)
        {
            Stopwatch sw = Stopwatch.StartNew();

            Origin = worldCenter - Vector3.one * (worldSize * 0.5f);
            LeafSize = worldSize / Mathf.Pow(2, MaxDepth);
            TotalNodeCount = 0;
            LeafNodeCount = 0;
            GroundVoxels = new Dictionary<uint, VoxelNode>();

            // Рекурсивна побудова дерева
            Root = BuildNode(worldCenter, worldSize, 0);

            // Класифікація листків (визначення Ground, Danger)
            ClassifyLeafNodes(Root);

            sw.Stop();
            Debug.Log($"[OctreeBuilder] Побудова завершена за {sw.ElapsedMilliseconds} мс. " +
                       $"Вузлів: {TotalNodeCount}, Листків: {LeafNodeCount}, " +
                       $"Ground-вокселів: {GroundVoxels.Count}, " +
                       $"Розмір листка: {LeafSize:F3} м");

            return Root;
        }

        // =====================================================================
        //  РЕКУРСИВНА ПОБУДОВА ДЕРЕВА
        // =====================================================================

        /// <summary>
        /// Рекурсивно будує вузол октодерева.
        /// Реалізує функцію BuildTree(Node, Depth) з теоретичного дослідження.
        /// </summary>
        private VoxelNode BuildNode(Vector3 center, float size, int depth)
        {
            VoxelNode node = new VoxelNode(center, size, depth);
            TotalNodeCount++;

            float halfSize = size * 0.5f;
            Vector3 halfExtents = Vector3.one * (halfSize + OVERLAP_EPSILON);

            // Перевіряємо, чи містить даний об'єм будь-яку геометрію сцени
            bool containsGeometry = Physics.CheckBox(
                center,
                halfExtents,
                Quaternion.identity,
                ObstacleLayerMask
            );

            // --- БАЗОВИЙ ВИПАДОК 1: Повністю порожня область ---
            if (!containsGeometry)
            {
                node.IsLeaf = true;
                node.IsSolid = false;
                node.Type = VoxelType.Empty;
                LeafNodeCount++;
                return node;
            }

            // --- БАЗОВИЙ ВИПАДОК 2: Досягнуто максимальної глибини ---
            if (depth >= MaxDepth)
            {
                node.IsLeaf = true;
                node.IsSolid = true;
                node.Type = VoxelType.Solid; // Буде уточнено на етапі класифікації
                LeafNodeCount++;
                return node;
            }

            // --- Перевіряємо однорідність: чи повністю зайнята область ---
            bool isFullySolid = IsRegionFullySolid(center, halfSize);
            if (isFullySolid)
            {
                node.IsLeaf = true;
                node.IsSolid = true;
                node.Type = VoxelType.Solid;
                LeafNodeCount++;
                return node;
            }

            // --- РЕКУРСИВНИЙ ВИПАДОК: Область неоднорідна — ділимо на 8 октантів ---
            node.IsLeaf = false;
            node.Children = new VoxelNode[8];

            float quarterSize = halfSize * 0.5f;

            for (int i = 0; i < 8; i++)
            {
                // Обчислюємо зміщення центру кожного октанта
                Vector3 childOffset = new Vector3(
                    (i & 1) == 0 ? -quarterSize : quarterSize,   // X: біт 0
                    (i & 2) == 0 ? -quarterSize : quarterSize,   // Y: біт 1
                    (i & 4) == 0 ? -quarterSize : quarterSize    // Z: біт 2
                );

                Vector3 childCenter = center + childOffset;
                node.Children[i] = BuildNode(childCenter, halfSize, depth + 1);
            }

            return node;
        }

        /// <summary>
        /// Перевіряє, чи є область повністю суцільною (без порожнечі).
        /// Використовує серію перевірок у внутрішніх точках.
        /// </summary>
        private bool IsRegionFullySolid(Vector3 center, float halfSize)
        {
            // Перевіряємо кілька точок всередині куба.
            // Якщо хоча б одна точка не знаходиться всередині колайдера — область не суцільна.
            float probeOffset = halfSize * 0.3f;

            Vector3[] probePoints = new Vector3[]
            {
                center,
                center + new Vector3(probeOffset, 0, 0),
                center + new Vector3(-probeOffset, 0, 0),
                center + new Vector3(0, probeOffset, 0),
                center + new Vector3(0, -probeOffset, 0),
                center + new Vector3(0, 0, probeOffset),
                center + new Vector3(0, 0, -probeOffset),
            };

            float smallRadius = halfSize * 0.05f;
            foreach (Vector3 probe in probePoints)
            {
                if (!Physics.CheckSphere(probe, smallRadius, ObstacleLayerMask))
                {
                    return false;
                }
            }

            return true;
        }

        // =====================================================================
        //  КЛАСИФІКАЦІЯ ЛИСТКІВ
        // =====================================================================

        /// <summary>
        /// Обходить дерево та класифікує листкові вузли.
        /// Ground-воксель — це порожній воксель, під яким є суцільний воксель.
        /// Danger-воксель — визначається за тегом колайдера.
        /// </summary>
        private void ClassifyLeafNodes(VoxelNode node)
        {
            if (node == null) return;

            if (node.IsLeaf)
            {
                ClassifySingleLeaf(node);
                return;
            }

            // Рекурсивний обхід для нелисткових вузлів
            for (int i = 0; i < 8; i++)
            {
                if (node.Children[i] != null)
                {
                    ClassifyLeafNodes(node.Children[i]);
                }
            }
        }

        /// <summary>
        /// Класифікує окремий листковий воксель.
        /// 
        /// Новий підхід — єдиний алгоритм для всіх типів геометрії:
        /// 1. Кидаємо промінь ЗВЕРХУ ВНИЗ через весь воксель.
        /// 2. Якщо знайдено горизонтальну поверхню — це потенційна Ground.
        /// 3. Перевіряємо: чи вміщується агент (капсула) НАД цією поверхнею?
        /// 4. Якщо так — реєструємо Ground-воксель на висоті поверхні.
        /// 
        /// Це працює для:
        /// - Звичайних платформ (промінь потрапляє у верхню грань)
        /// - Сходів (промінь потрапляє у кожну сходинку)
        /// - Платформи під нависом (clearance check відсіює)
        /// - Платформи на будь-якій висоті
        /// </summary>
        private void ClassifySingleLeaf(VoxelNode leaf)
        {
            // === 1. ПЕРЕВІРКА DANGER ===
            Collider[] overlaps = Physics.OverlapBox(
                leaf.Center,
                Vector3.one * (leaf.Size * 0.5f),
                Quaternion.identity,
                ObstacleLayerMask
            );

            foreach (Collider col in overlaps)
            {
                if (col.CompareTag(DangerTag))
                {
                    leaf.Type = VoxelType.Danger;
                    leaf.DangerLevel = 1.0f;
                    return;
                }
            }

            // === 2. ПОШУК ПРОХІДНОЇ ПОВЕРХНІ ===
            // Промінь стартує з верхньої грані вокселя і йде вниз
            // тільки на 1 розмір вокселя. Це гарантує що знайдена поверхня
            // безпосередньо торкається цього вокселя, а не знаходиться далеко внизу.
            Vector3 rayOrigin = leaf.Center + Vector3.up * (leaf.Size * 0.6f);
            float rayLength = leaf.Size * 1.2f; // Тільки в межах вокселя

            if (!Physics.Raycast(rayOrigin, Vector3.down, out RaycastHit hit,
                                  rayLength, ObstacleLayerMask,
                                  QueryTriggerInteraction.Ignore))
            {
                return;
            }

            float angle = Vector3.Angle(hit.normal, Vector3.up);
            if (angle > MaxWalkableAngle || hit.normal.y < 0.5f)
            {
                return;
            }

            // Поверхня має бути в межах ОДНОГО розміру вокселя від його центру
            float surfaceY = hit.point.y;
            if (Mathf.Abs(surfaceY - leaf.Center.y) > leaf.Size * 0.8f)
            {
                return;
            }

            // === 3. ПЕРЕВІРКА CLEARANCE (чи вміщується агент) ===
            // Перевіряємо капсулою: чи є достатньо вільного простору
            // над знайденою поверхнею для агента висотою 1.8м.
            float agentRadius = 0.3f;  // Використовуємо стандартні значення,
            float agentHeight = 1.8f;  // бо AgentParameters тут недоступний.

            // Центр капсули — на висоті surfaceY + halfHeight
            Vector3 capsuleBottom = new Vector3(leaf.Center.x, surfaceY + agentRadius + 0.05f, leaf.Center.z);
            Vector3 capsuleTop = new Vector3(leaf.Center.x, surfaceY + agentHeight - agentRadius, leaf.Center.z);

            bool hasSpace = !Physics.CheckCapsule(
                capsuleBottom, capsuleTop, agentRadius * 0.85f,
                ObstacleLayerMask, QueryTriggerInteraction.Ignore);

            if (!hasSpace)
            {
                return; // Недостатньо місця для агента (низька стеля, летюча платформа)
            }

            // === 4. РЕЄСТРАЦІЯ GROUND-ВОКСЕЛЯ ===
            // Створюємо Ground-воксель на висоті знайденої поверхні
            Vector3 groundPos = new Vector3(leaf.Center.x, surfaceY + LeafSize * 0.5f, leaf.Center.z);

            Vector3Int idx = MortonCode.WorldToIndex(groundPos, Origin, LeafSize);

            if (idx.x < 0 || idx.x >= 1024 ||
                idx.y < 0 || idx.y >= 1024 ||
                idx.z < 0 || idx.z >= 1024)
            {
                return; // За межами
            }

            uint code = MortonCode.Encode(idx.x, idx.y, idx.z);

            if (GroundVoxels.ContainsKey(code))
            {
                return; // Вже зареєстровано
            }

            // Якщо leaf — порожній і поверхня прямо під ним — оновлюємо сам leaf
            if (!leaf.IsSolid && Mathf.Abs(surfaceY - (leaf.Center.y - leaf.Size * 0.5f)) < leaf.Size)
            {
                leaf.Type = VoxelType.Ground;
                leaf.SurfaceNormal = hit.normal;
                leaf.MortonCode = code;
                GroundVoxels[code] = leaf;
            }
            else
            {
                // Інакше створюємо віртуальний Ground-воксель (для сходів)
                VoxelNode groundVoxel = new VoxelNode(groundPos, leaf.Size, leaf.Depth);
                groundVoxel.Type = VoxelType.Ground;
                groundVoxel.IsSolid = false;
                groundVoxel.SurfaceNormal = hit.normal;
                groundVoxel.MortonCode = code;
                GroundVoxels[code] = groundVoxel;
            }
        }

        // =====================================================================
        //  ДОПОМІЖНІ МЕТОДИ (ЗАПИТИ ДО ДЕРЕВА)
        // =====================================================================

        /// <summary>
        /// Знаходить воксель, що містить задану точку у просторі.
        /// Спускається по дереву від кореня до листка.
        /// Складність: O(MaxDepth) — дуже швидко.
        /// </summary>
        /// <param name="point">Точка у світових координатах</param>
        /// <returns>Листковий вузол або null, якщо точка поза межами</returns>
        public VoxelNode QueryPoint(Vector3 point)
        {
            return QueryPointRecursive(Root, point);
        }

        private VoxelNode QueryPointRecursive(VoxelNode node, Vector3 point)
        {
            if (node == null) return null;
            if (node.IsLeaf) return node;

            // Визначаємо, у який октант потрапляє точка
            int childIndex = 0;
            if (point.x >= node.Center.x) childIndex |= 1;
            if (point.y >= node.Center.y) childIndex |= 2;
            if (point.z >= node.Center.z) childIndex |= 4;

            return QueryPointRecursive(node.Children[childIndex], point);
        }

        /// <summary>
        /// Перевіряє, чи є задана точка у суцільному (непрохідному) вокселі.
        /// Використовується для перевірки колізій на траєкторії стрибка.
        /// </summary>
        public bool IsPointBlocked(Vector3 point)
        {
            VoxelNode node = QueryPoint(point);
            if (node == null) return true; // За межами — вважаємо непрохідним
            return node.IsSolid;
        }

        /// <summary>
        /// Перевіряє, чи є відрізок між двома точками вільним від перешкод.
        /// Дискретизує відрізок і перевіряє кожну точку.
        /// Використовується для валідації балістичних траєкторій.
        /// </summary>
        /// <param name="from">Початкова точка</param>
        /// <param name="to">Кінцева точка</param>
        /// <param name="steps">Кількість кроків дискретизації</param>
        /// <returns>true, якщо шлях вільний</returns>
        public bool IsPathClear(Vector3 from, Vector3 to, int steps = 10)
        {
            for (int i = 0; i <= steps; i++)
            {
                float t = (float)i / steps;
                Vector3 point = Vector3.Lerp(from, to, t);

                if (IsPointBlocked(point))
                    return false;
            }
            return true;
        }

        /// <summary>
        /// Збирає всі листкові вузли дерева у список.
        /// Корисно для візуалізації та аналізу.
        /// </summary>
        public List<VoxelNode> GetAllLeaves()
        {
            List<VoxelNode> leaves = new List<VoxelNode>();
            CollectLeaves(Root, leaves);
            return leaves;
        }

        private void CollectLeaves(VoxelNode node, List<VoxelNode> leaves)
        {
            if (node == null) return;

            if (node.IsLeaf)
            {
                leaves.Add(node);
                return;
            }

            for (int i = 0; i < 8; i++)
            {
                CollectLeaves(node.Children[i], leaves);
            }
        }
    }
}