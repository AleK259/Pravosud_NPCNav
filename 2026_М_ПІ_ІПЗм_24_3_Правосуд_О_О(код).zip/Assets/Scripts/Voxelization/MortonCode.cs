﻿using UnityEngine;

namespace Navigation.Voxelization
{
    /// <summary>
    /// Утиліта для кодування/декодування коду Мортона (Z-order curve).
    /// Лінеаризує тривимірні координати (x, y, z) у одне ціле число,
    /// що прискорює доступ до пам'яті завдяки просторовій локальності даних.
    /// 
    /// Формула: M = Σ(xi · 2^(3i) + yi · 2^(3i+1) + zi · 2^(3i+2))
    /// де xi, yi, zi — біти двійкового представлення координат.
    /// </summary>
    public static class MortonCode
    {
        /// <summary>
        /// Кодує тривимірні цілочисельні координати у код Мортона.
        /// Підтримує координати в діапазоні [0, 1023] (10 біт на вісь).
        /// </summary>
        /// <param name="x">Координата X (0–1023)</param>
        /// <param name="y">Координата Y (0–1023)</param>
        /// <param name="z">Координата Z (0–1023)</param>
        /// <returns>32-бітний код Мортона</returns>
        public static uint Encode(int x, int y, int z)
        {
            uint xx = ExpandBits((uint)x);
            uint yy = ExpandBits((uint)y);
            uint zz = ExpandBits((uint)z);

            // Чергування бітів: x займає позиції 0,3,6,...
            // y — позиції 1,4,7,...  z — позиції 2,5,8,...
            return xx | (yy << 1) | (zz << 2);
        }

        /// <summary>
        /// Декодує код Мортона назад у тривимірні координати.
        /// </summary>
        /// <param name="code">Код Мортона</param>
        /// <returns>Вектор з цілочисельними координатами (x, y, z)</returns>
        public static Vector3Int Decode(uint code)
        {
            int x = (int)CompactBits(code);
            int y = (int)CompactBits(code >> 1);
            int z = (int)CompactBits(code >> 2);
            return new Vector3Int(x, y, z);
        }

        /// <summary>
        /// Перетворює світові координати у дискретні індекси вокселів
        /// відносно початку октодерева.
        /// </summary>
        /// <param name="worldPos">Позиція у світових координатах</param>
        /// <param name="octreeOrigin">Мінімальний кут октодерева</param>
        /// <param name="voxelSize">Розмір найменшого вокселя</param>
        /// <returns>Дискретні індекси (ix, iy, iz)</returns>
        public static Vector3Int WorldToIndex(Vector3 worldPos, Vector3 octreeOrigin, float voxelSize)
        {
            Vector3 local = worldPos - octreeOrigin;
            int ix = Mathf.FloorToInt(local.x / voxelSize);
            int iy = Mathf.FloorToInt(local.y / voxelSize);
            int iz = Mathf.FloorToInt(local.z / voxelSize);
            return new Vector3Int(ix, iy, iz);
        }

        /// <summary>
        /// Обчислює код Мортона безпосередньо зі світових координат.
        /// </summary>
        public static uint EncodeWorldPosition(Vector3 worldPos, Vector3 octreeOrigin, float voxelSize)
        {
            Vector3Int idx = WorldToIndex(worldPos, octreeOrigin, voxelSize);
            return Encode(idx.x, idx.y, idx.z);
        }

        /// <summary>
        /// Розширює біти числа для чергування.
        /// Кожен біт вхідного числа розміщується з інтервалом 3
        /// (між ними залишається місце для бітів інших осей).
        /// 
        /// Приклад: 0b1011 → 0b001_000_001_001
        /// </summary>
        private static uint ExpandBits(uint v)
        {
            // Обмежуємо до 10 біт (максимум 1023)
            v &= 0x000003FFu;

            // Магічні числа для паралельного розширення бітів
            // Кожен крок "розсуває" біти далі один від одного
            v = (v | (v << 16)) & 0x030000FFu; // __xx xxxxxxxx -> __xx ________ xxxxxxxx
            v = (v | (v << 8))  & 0x0300F00Fu; // розсуваємо по 4 біти
            v = (v | (v << 4))  & 0x030C30C3u; // розсуваємо по 2 біти
            v = (v | (v << 2))  & 0x09249249u; // розсуваємо по 1 біту

            return v;
        }

        /// <summary>
        /// Операція, зворотна до ExpandBits.
        /// Стискає розріджені біти назад у щільне число.
        /// </summary>
        private static uint CompactBits(uint v)
        {
            v &= 0x09249249u;
            v = (v | (v >> 2))  & 0x030C30C3u;
            v = (v | (v >> 4))  & 0x0300F00Fu;
            v = (v | (v >> 8))  & 0x030000FFu;
            v = (v | (v >> 16)) & 0x000003FFu;
            return v;
        }
    }
}