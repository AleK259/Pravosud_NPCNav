using UnityEngine;

namespace Navigation.Voxelization
{
    /// <summary>
    /// Тип вокселя у просторі сцени.
    /// </summary>
    public enum VoxelType
    {
        Empty,   // Порожній простір (повітря)
        Solid,   // Суцільна перешкода (стіна, декор)
        Ground,  // Поверхня, придатна для переміщення
        Danger   // Небезпечна зона (лава, прірва)
    }

    /// <summary>
    /// Вузол октодерева. Описує кубічну область простору.
    /// Якщо isLeaf = true, вузол є листком і містить інформацію про тип вокселя.
    /// Інакше — має 8 дочірніх вузлів (октантів).
    /// </summary>
    public class VoxelNode
    {
        // --- Просторові параметри ---
        public Vector3 Center { get; private set; }
        public float Size { get; private set; }
        public int Depth { get; private set; }

        // --- Ієрархія дерева ---
        public VoxelNode[] Children { get; set; }
        public bool IsLeaf { get; set; }

        // --- Атрибути вокселя (тільки для листків) ---
        public bool IsSolid { get; set; }
        public VoxelType Type { get; set; }
        public float DangerLevel { get; set; }

        // --- Навігаційні дані ---
        /// <summary>
        /// Код Мортона для швидкого доступу та лінеаризації координат.
        /// </summary>
        public uint MortonCode { get; set; }

        /// <summary>
        /// Нормаль поверхні (актуально для Ground-вокселів).
        /// Використовується для перевірки кута нахилу при приземленні.
        /// </summary>
        public Vector3 SurfaceNormal { get; set; }

        public VoxelNode(Vector3 center, float size, int depth)
        {
            Center = center;
            Size = size;
            Depth = depth;
            Children = null;
            IsLeaf = true;
            IsSolid = false;
            Type = VoxelType.Empty;
            DangerLevel = 0f;
            SurfaceNormal = Vector3.up;
        }

        /// <summary>
        /// Мінімальний кут AABB (Axis-Aligned Bounding Box) вокселя.
        /// </summary>
        public Vector3 Min => Center - Vector3.one * (Size * 0.5f);

        /// <summary>
        /// Максимальний кут AABB вокселя.
        /// </summary>
        public Vector3 Max => Center + Vector3.one * (Size * 0.5f);

        /// <summary>
        /// Чи є воксель прохідним для агента (порожній або Ground).
        /// </summary>
        public bool IsWalkable => Type == VoxelType.Ground;

        /// <summary>
        /// Чи може агент пролітати через цей воксель (порожній простір).
        /// </summary>
        public bool IsTraversableAir => Type == VoxelType.Empty;
    }
}
