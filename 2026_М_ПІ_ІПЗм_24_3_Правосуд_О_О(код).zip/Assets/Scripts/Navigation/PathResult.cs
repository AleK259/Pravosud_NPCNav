using System.Collections.Generic;
using UnityEngine;
using Navigation.Voxelization;

namespace Navigation
{
    /// <summary>
    /// Статус результату пошуку шляху.
    /// </summary>
    public enum PathStatus
    {
        Found,          // Шлях знайдено
        NotFound,       // Шлях не існує (ціль недосяжна)
        Timeout,        // Перевищено ліміт ітерацій або часу
        InvalidStart,   // Стартова позиція не на Ground-вокселі
        InvalidGoal     // Цільова позиція не на Ground-вокселі
    }

    /// <summary>
    /// Один крок маршруту — описує перехід від одного вузла до наступного.
    /// </summary>
    public struct PathStep
    {
        /// <summary>Позиція, до якої потрібно дістатися на цьому кроці.</summary>
        public Vector3 Position;

        /// <summary>Вузол октодерева, що відповідає цій позиції.</summary>
        public VoxelNode Node;

        /// <summary>Тип переходу ДО цієї точки (Walk/Jump/Fall).</summary>
        public EdgeType TransitionType;

        /// <summary>Вектор швидкості для стрибка (тільки для Jump).</summary>
        public Vector3 LaunchVelocity;

        /// <summary>Час польоту (тільки для Jump/Fall).</summary>
        public float FlightTime;

        /// <summary>Вартість цього переходу.</summary>
        public float StepCost;
    }

    /// <summary>
    /// Результат роботи алгоритму A*.
    /// Містить повний маршрут з деталями кожного переходу,
    /// а також метрики для аналізу продуктивності (для звіту).
    /// </summary>
    public class PathResult
    {
        /// <summary>Статус пошуку.</summary>
        public PathStatus Status { get; set; }

        /// <summary>Список кроків маршруту (від старту до цілі).</summary>
        public List<PathStep> Steps { get; set; }

        /// <summary>Загальна вартість маршруту (сума g-значень).</summary>
        public float TotalCost { get; set; }

        /// <summary>Час виконання алгоритму (мілісекунди).</summary>
        public float SearchTimeMs { get; set; }

        /// <summary>Кількість ітерацій (розкритих вузлів).</summary>
        public int IterationCount { get; set; }

        /// <summary>Максимальний розмір Open List під час пошуку.</summary>
        public int MaxOpenListSize { get; set; }

        /// <summary>Кількість стрибків у маршруті.</summary>
        public int JumpCount
        {
            get
            {
                int count = 0;
                if (Steps != null)
                    foreach (var step in Steps)
                        if (step.TransitionType == EdgeType.Jump) count++;
                return count;
            }
        }

        /// <summary>Кількість падінь у маршруті.</summary>
        public int FallCount
        {
            get
            {
                int count = 0;
                if (Steps != null)
                    foreach (var step in Steps)
                        if (step.TransitionType == EdgeType.Fall) count++;
                return count;
            }
        }

        /// <summary>Загальна довжина маршруту (метри).</summary>
        public float TotalDistance
        {
            get
            {
                if (Steps == null || Steps.Count < 2) return 0f;
                float dist = 0f;
                for (int i = 1; i < Steps.Count; i++)
                    dist += Vector3.Distance(Steps[i - 1].Position, Steps[i].Position);
                return dist;
            }
        }

        /// <summary>Чи знайдено шлях.</summary>
        public bool IsSuccess => Status == PathStatus.Found;

        /// <summary>
        /// Масив позицій маршруту (для швидкого доступу).
        /// </summary>
        public Vector3[] GetPositions()
        {
            if (Steps == null) return new Vector3[0];
            Vector3[] positions = new Vector3[Steps.Count];
            for (int i = 0; i < Steps.Count; i++)
                positions[i] = Steps[i].Position;
            return positions;
        }

        /// <summary>
        /// Формує текстовий звіт для логування та аналізу.
        /// </summary>
        public override string ToString()
        {
            return $"[PathResult] Status: {Status}, " +
                   $"Steps: {Steps?.Count ?? 0}, " +
                   $"Cost: {TotalCost:F2}, " +
                   $"Distance: {TotalDistance:F2}m, " +
                   $"Jumps: {JumpCount}, Falls: {FallCount}, " +
                   $"Time: {SearchTimeMs:F2}ms, " +
                   $"Iterations: {IterationCount}, " +
                   $"MaxOpenList: {MaxOpenListSize}";
        }
    }
}
