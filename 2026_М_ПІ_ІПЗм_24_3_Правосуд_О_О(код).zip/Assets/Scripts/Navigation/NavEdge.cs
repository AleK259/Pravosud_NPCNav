using UnityEngine;
using Navigation.Voxelization;

namespace Navigation
{
    /// <summary>
    /// Тип переходу між вузлами навігаційного графа.
    /// </summary>
    public enum EdgeType
    {
        Walk,   // Пішохідний рух по поверхні
        Jump,   // Стрибок через повітря (балістична траєкторія)
        Fall    // Падіння вниз (безкоштовний перехід з обрива)
    }

    /// <summary>
    /// Ребро навігаційного графа — описує можливий перехід між двома вокселями.
    /// 
    /// Не зберігається статично — генерується "на льоту" при розкритті
    /// вузла в алгоритмі A* (відповідно до розділу 4.4 роботи).
    /// </summary>
    public struct NavEdge
    {
        /// <summary>Вузол-джерело (звідки рухаємося).</summary>
        public VoxelNode From;

        /// <summary>Вузол-ціль (куди рухаємося).</summary>
        public VoxelNode To;

        /// <summary>Тип переходу.</summary>
        public EdgeType Type;

        /// <summary>
        /// Вартість переходу (для алгоритму A*).
        /// Для Walk — евклідова відстань × коефіцієнт.
        /// Для Jump — час польоту × коефіцієнт ризику.
        /// Для Fall — невелика фіксована вартість.
        /// </summary>
        public float Cost;

        /// <summary>
        /// Початковий вектор швидкості стрибка (тільки для Jump).
        /// Це v₀ з формули p(t) = p₀ + v₀t + ½gt² (розділ 4.5 роботи).
        /// Для Walk та Fall — Vector3.zero.
        /// </summary>
        public Vector3 LaunchVelocity;

        /// <summary>
        /// Час польоту у секундах (тільки для Jump/Fall).
        /// Потрібен для дискретизації та перевірки траєкторії.
        /// </summary>
        public float FlightTime;

        /// <summary>
        /// Створює ребро пішохідного переходу.
        /// </summary>
        public static NavEdge CreateWalk(VoxelNode from, VoxelNode to, float cost)
        {
            return new NavEdge
            {
                From = from,
                To = to,
                Type = EdgeType.Walk,
                Cost = cost,
                LaunchVelocity = Vector3.zero,
                FlightTime = 0f
            };
        }

        /// <summary>
        /// Створює ребро стрибка.
        /// </summary>
        public static NavEdge CreateJump(VoxelNode from, VoxelNode to,
                                          float cost, Vector3 launchVelocity, float flightTime)
        {
            return new NavEdge
            {
                From = from,
                To = to,
                Type = EdgeType.Jump,
                Cost = cost,
                LaunchVelocity = launchVelocity,
                FlightTime = flightTime
            };
        }

        /// <summary>
        /// Створює ребро падіння.
        /// </summary>
        public static NavEdge CreateFall(VoxelNode from, VoxelNode to, float cost, float fallTime)
        {
            return new NavEdge
            {
                From = from,
                To = to,
                Type = EdgeType.Fall,
                Cost = cost,
                LaunchVelocity = Vector3.zero,
                FlightTime = fallTime
            };
        }
    }
}
