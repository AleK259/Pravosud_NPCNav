using UnityEngine;
using Navigation.Agent;

namespace Navigation
{
    /// <summary>
    /// Кінематична модель стрибка агента.
    /// 
    /// Розв'язує обернену задачу балістики (розділ 4.5 роботи):
    /// задано початкову точку p₀ та цільову точку p₁,
    /// знайти вектор початкової швидкості v₀, при якому
    /// p(t) = p₀ + v₀·t + ½·g·t² = p₁ для деякого t > 0.
    /// 
    /// Також перевіряє траєкторію на колізії шляхом дискретизації
    /// з кроком Δt та фізичних запитів Unity (SphereCast / CheckCapsule).
    /// </summary>
    public class JumpPhysics
    {
        private readonly AgentParameters agentParams;
        private readonly LayerMask obstacleMask;

        /// <summary>
        /// Крок дискретизації траєкторії за часом (секунди).
        /// Менше значення = точніша перевірка, але повільніша.
        /// </summary>
        public float TrajectoryTimeStep { get; set; } = 0.1f;

        public JumpPhysics(AgentParameters agentParams, LayerMask obstacleMask)
        {
            this.agentParams = agentParams;
            this.obstacleMask = obstacleMask;
        }

        // =====================================================================
        //  ОБЕРНЕНА ЗАДАЧА БАЛІСТИКИ
        // =====================================================================

        /// <summary>
        /// Визначає, чи може агент дістатися з точки from до точки to стрибком.
        /// Розв'язує обернену задачу балістики та перевіряє кінематичні обмеження.
        /// 
        /// Формула: p(t) = p₀ + v₀·t + ½·g·t²
        /// Розв'язок зводиться до вибору часу польоту T та обчислення v₀.
        /// </summary>
        /// <param name="from">Позиція відштовхування</param>
        /// <param name="to">Цільова позиція приземлення</param>
        /// <param name="launchVelocity">Вихідний параметр: вектор початкової швидкості</param>
        /// <param name="flightTime">Вихідний параметр: час польоту</param>
        /// <returns>true, якщо стрибок фізично можливий</returns>
        public bool CanReach(Vector3 from, Vector3 to,
                             out Vector3 launchVelocity, out float flightTime)
        {
            launchVelocity = Vector3.zero;
            flightTime = 0f;

            Vector3 delta = to - from;
            float horizontalDist = new Vector2(delta.x, delta.z).magnitude;
            float verticalDist = delta.y;

            if (horizontalDist > agentParams.MaxJumpDistance)
                return false;
            if (verticalDist > agentParams.MaxJumpHeight)
                return false;

            float estimatedTime = horizontalDist / (agentParams.maxJumpSpeed * 0.5f);
            if (estimatedTime < 0.3f) estimatedTime = 0.3f;

            // Пробуємо варіанти від ПОВІЛЬНОГО (висока дуга) до ШВИДКОГО (низька дуга).
            // Перший що пройде ValidateTrajectory — найвища безпечна траєкторія.
            float[] timesToTry = new float[]
            {
                estimatedTime * 2.0f,
                estimatedTime * 1.5f,
                estimatedTime * 1.2f,
                estimatedTime,
                estimatedTime * 0.8f,
            };

            foreach (float t in timesToTry)
            {
                if (t < 0.15f || t > agentParams.MaxAirTime) continue;

                Vector3 v0 = ComputeLaunchVelocity(from, to, t);
                float speed = v0.magnitude;

                if (speed > agentParams.maxJumpSpeed) continue;
                if (v0.y > agentParams.maxJumpVerticalSpeed) continue;
                if (v0.y < -1f) continue;

                // Єдина перевірка — ValidateTrajectory (CapsuleCast вздовж параболи).
                // Вона враховує повні розміри агента і всю геометрію.
                if (ValidateTrajectory(from, v0, t))
                {
                    launchVelocity = v0;
                    flightTime = t;
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Обчислює вектор початкової швидкості для заданого часу польоту.
        /// 
        /// З формули p(t) = p₀ + v₀·t + ½·g·t²:
        /// v₀ = (p₁ - p₀ - ½·g·t²) / t
        /// </summary>
        /// <param name="from">Початкова позиція</param>
        /// <param name="to">Цільова позиція</param>
        /// <param name="time">Час польоту (секунди)</param>
        /// <returns>Вектор початкової швидкості або Vector3.zero при помилці</returns>
        public Vector3 ComputeLaunchVelocity(Vector3 from, Vector3 to, float time)
        {
            if (time <= 0.001f) return Vector3.zero;

            Vector3 delta = to - from;
            Vector3 gravity = agentParams.GravityVector;

            // v₀ = (Δp - ½·g·t²) / t
            Vector3 v0 = (delta - 0.5f * gravity * time * time) / time;

            return v0;
        }

        // =====================================================================
        //  ВАЛІДАЦІЯ ТРАЄКТОРІЇ (перевірка на колізії)
        // =====================================================================

        /// <summary>
        /// Перевіряє, чи вільна балістична траєкторія від перешкод.
        /// Дискретизує параболу з кроком Δt і для кожної точки
        /// виконує фізичну перевірку (SphereCast з розмірами агента).
        /// 
        /// Це реалізація перевірки з розділу 4.5 роботи:
        /// "для кожної точки p(tᵢ) виконується перевірка перетину
        /// об'єму агента з вокселями октодерева".
        /// </summary>
        /// <param name="from">Точка старту стрибка</param>
        /// <param name="launchVelocity">Початковий вектор швидкості</param>
        /// <param name="flightTime">Час польоту</param>
        /// <returns>true, якщо траєкторія вільна від перешкод</returns>
        public bool ValidateTrajectory(Vector3 from, Vector3 launchVelocity, float flightTime)
        {
            Vector3 gravity = agentParams.GravityVector;
            float radius = agentParams.radius;
            float halfHeight = agentParams.HalfHeight;

            // Перевіряємо 5%–95% траєкторії (10 сегментів).
            // Мінімальні сліпі зони на старті і фініші.
            int segments = 10;
            float startFrac = 0.05f;
            float endFrac = 0.95f;

            Vector3 prevCenter = Vector3.zero;
            bool hasPrev = false;

            for (int i = 0; i <= segments; i++)
            {
                float frac = Mathf.Lerp(startFrac, endFrac, (float)i / segments);
                float t = frac * flightTime;

                // Точка на параболі = вже центр капсули (from піднятий у BuildJumpEdges)
                Vector3 capsuleCenter = from + launchVelocity * t + 0.5f * gravity * t * t;

                if (hasPrev)
                {
                    // CapsuleCast від попередньої точки до поточної
                    Vector3 direction = capsuleCenter - prevCenter;
                    float segmentLength = direction.magnitude;

                    if (segmentLength > 0.01f)
                    {
                        // Нижня та верхня точки капсули
                        float innerOffset = halfHeight - radius;
                        Vector3 p1 = prevCenter - Vector3.up * innerOffset;
                        Vector3 p2 = prevCenter + Vector3.up * innerOffset;

                        if (Physics.CapsuleCast(p1, p2, radius,
                                                 direction.normalized, segmentLength,
                                                 obstacleMask,
                                                 QueryTriggerInteraction.Ignore))
                        {
                            return false; // Сегмент перетинає перешкоду
                        }
                    }
                }

                prevCenter = capsuleCenter;
                hasPrev = true;
            }

            return true;
        }

        // =====================================================================
        //  КОМБІНОВАНИЙ МЕТОД (CanReach + ValidateTrajectory)
        // =====================================================================

        /// <summary>
        /// Повна перевірка можливості стрибка: розрахунок балістики + валідація траєкторії.
        /// CanReach тепер включає ValidateTrajectory всередині — перевіряє кілька
        /// варіантів траєкторії від найвищої до найнижчої і повертає першу безпечну.
        /// </summary>
        public bool TryJump(Vector3 from, Vector3 to,
                            out Vector3 launchVelocity, out float flightTime)
        {
            return CanReach(from, to, out launchVelocity, out flightTime);
        }

        // =====================================================================
        //  ДОПОМІЖНІ МЕТОДИ
        // =====================================================================

        /// <summary>
        /// Обчислює позицію агента на траєкторії у заданий момент часу.
        /// Використовується для візуалізації параболи (Gizmos).
        /// </summary>
        public Vector3 GetPositionAtTime(Vector3 from, Vector3 launchVelocity, float t)
        {
            return from + launchVelocity * t + 0.5f * agentParams.GravityVector * t * t;
        }

        /// <summary>
        /// Обчислює швидкість агента у заданий момент часу.
        /// v(t) = v₀ + g·t
        /// </summary>
        public Vector3 GetVelocityAtTime(Vector3 launchVelocity, float t)
        {
            return launchVelocity + agentParams.GravityVector * t;
        }

        /// <summary>
        /// Повертає масив точок параболічної траєкторії для візуалізації.
        /// </summary>
        /// <param name="from">Початкова точка</param>
        /// <param name="launchVelocity">Вектор швидкості</param>
        /// <param name="flightTime">Час польоту</param>
        /// <param name="resolution">Кількість точок на кривій</param>
        public Vector3[] GetTrajectoryPoints(Vector3 from, Vector3 launchVelocity,
                                              float flightTime, int resolution = 20)
        {
            Vector3[] points = new Vector3[resolution + 1];

            for (int i = 0; i <= resolution; i++)
            {
                float t = (float)i / resolution * flightTime;
                points[i] = GetPositionAtTime(from, launchVelocity, t);
            }

            return points;
        }

        /// <summary>
        /// Оцінює "вартість ризику" стрибка для алгоритму A*.
        /// 
        /// КЛЮЧОВИЙ ПРИНЦИП: стрибок завжди дорожчий за ходьбу на ту саму відстань.
        /// Це гарантує, що A* обере стрибок лише коли пішохідний шлях неможливий
        /// (розрив між платформами). Без цього агент стрибає замість ходьби.
        /// 
        /// Також реалізує асиметрію з розділу 3.3:
        /// "зістрибнути вниз легко, застрибнути вгору — важко".
        /// </summary>
        public float EstimateJumpCost(Vector3 from, Vector3 to,
                                       Vector3 launchVelocity, float flightTime)
        {
            float distance = Vector3.Distance(from, to);
            float speed = launchVelocity.magnitude;
            float maxSpeed = agentParams.maxJumpSpeed;

            // Базова вартість — евклідова відстань (як при ходьбі)
            float baseCost = distance;

            // Фіксований штраф за сам факт стрибка (ризик приземлення, втрата контролю)
            float jumpPenalty = 3.0f;

            // Множник складності: чим ближче до максимальної швидкості, тим ризикованіше
            // Діапазон: 1.5 (легкий стрибок) — 3.5 (на межі можливостей)
            float difficultyMultiplier = 1.5f + 2f * (speed / maxSpeed);

            // Штраф за набір висоти (стрибок вгору складніший за падіння)
            float heightDiff = to.y - from.y;
            float heightPenalty = heightDiff > 0 ? heightDiff * 1.0f : 0f;

            return baseCost * difficultyMultiplier + jumpPenalty + heightPenalty;
        }
    }
}