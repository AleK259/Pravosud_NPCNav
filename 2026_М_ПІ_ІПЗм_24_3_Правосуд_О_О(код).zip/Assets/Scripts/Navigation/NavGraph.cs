using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;
using Navigation.Agent;
using Navigation.Voxelization;
using Debug = UnityEngine.Debug;

namespace Navigation
{
    /// <summary>
    /// Навігаційний граф G(V, E) для алгоритму A*.
    /// 
    /// АРХІТЕКТУРА: всі ребра обчислюються ОДИН РАЗ при побудові графа.
    /// A* тільки читає готовий словник сусідів — 0 фізичних перевірок під час пошуку.
    /// 
    /// Це вирішує дві проблеми:
    /// 1. Швидкість: A* не витрачає час на Physics під час пошуку.
    /// 2. Коректність: всі вузли мають повний набір ребер, без пропусків.
    /// </summary>
    public class NavGraph
    {
        private readonly Dictionary<uint, VoxelNode> groundVoxels;
        private readonly OctreeBuilder octree;
        private readonly JumpPhysics jumpPhysics;
        private readonly AgentParameters agentParams;

        // Просторовий хеш для швидкого пошуку сусідів при побудові
        private readonly SpatialHashGrid walkGrid;
        private readonly SpatialHashGrid jumpGrid;

        // Попередньо обчислені ребра для кожного вузла
        private readonly Dictionary<VoxelNode, List<NavEdge>> precomputedEdges;

        // Близькість до краю платформи для кожного вокселя (0 = центр, 1 = на краю)
        private readonly Dictionary<VoxelNode, float> edgeProximity;

        // --- Налаштування ---

        public float WalkNeighborRange { get; set; } = 1.8f;
        public float WalkCostMultiplier { get; set; } = 1.0f;
        public float FallCostMultiplier { get; set; } = 0.8f;
        public float MaxWalkHeightDiff { get; set; } = 0.5f;
        public float MaxSafeFallHeight { get; set; } = 5f;

        /// <summary>
        /// Множник "страху падіння". Вартість walk-ребра біля краю платформи
        /// збільшується на цей множник. 0 = вимкнено, 3 = сильний страх.
        /// Формула: cost *= 1 + FallFearMultiplier * edgeProximity
        /// </summary>
        public float FallFearMultiplier { get; set; } = 2.0f;

        public bool enableDebugLog = false;

        // =====================================================================
        //  КОНСТРУКТОР
        // =====================================================================

        public NavGraph(OctreeBuilder octree, JumpPhysics jumpPhysics, AgentParameters agentParams)
        {
            this.octree = octree;
            this.jumpPhysics = jumpPhysics;
            this.agentParams = agentParams;
            this.groundVoxels = octree.GroundVoxels;
            this.precomputedEdges = new Dictionary<VoxelNode, List<NavEdge>>();
            this.edgeProximity = new Dictionary<VoxelNode, float>();

            float walkCellSize = 2.0f;
            float jumpCellSize = agentParams.MaxJumpDistance;

            walkGrid = new SpatialHashGrid(walkCellSize);
            jumpGrid = new SpatialHashGrid(jumpCellSize);

            walkGrid.Build(groundVoxels.Values);
            jumpGrid.Build(groundVoxels.Values);
        }

        /// <summary>
        /// Будує всі ребра графа. Викликається ПІСЛЯ встановлення параметрів
        /// (FallFearMultiplier, MaxSafeFallHeight тощо).
        /// </summary>
        public void BuildEdges()
        {
            ComputeEdgeProximity();
            PrecomputeAllEdges();
        }

        public int NodeCount => groundVoxels.Count;
        public IEnumerable<VoxelNode> AllNodes => groundVoxels.Values;

        /// <summary>
        /// Публічний доступ до карти близькості до краю (для візуалізації).
        /// </summary>
        public Dictionary<VoxelNode, float> EdgeProximity => edgeProximity;

        // =====================================================================
        //  ОБЧИСЛЕННЯ БЛИЗЬКОСТІ ДО КРАЮ
        // =====================================================================

        /// <summary>
        /// Для кожного Ground-вокселя обчислює наскільки він близько до краю платформи.
        /// Значення 0 = центр платформи (безпечно), 1 = на самому краю (небезпечно).
        /// 
        /// Алгоритм: кидаємо 8 променів вниз у горизонтальних напрямках
        /// (±X, ±Z, 4 діагоналі). Рахуємо скільки з них НЕ знайшли землю.
        /// Більше прірв навколо = ближче до краю.
        /// </summary>
        private void ComputeEdgeProximity()
        {
            float rayHeight = 1.5f;
            float rayLength = 3f;

            foreach (VoxelNode node in groundVoxels.Values)
            {
                float checkDist = node.Size * 1.5f;
                int totalDirs = 8;
                int missingGround = 0;

                Vector3[] offsets = {
                    new Vector3(checkDist, 0, 0),
                    new Vector3(-checkDist, 0, 0),
                    new Vector3(0, 0, checkDist),
                    new Vector3(0, 0, -checkDist),
                    new Vector3(checkDist, 0, checkDist).normalized * checkDist,
                    new Vector3(checkDist, 0, -checkDist).normalized * checkDist,
                    new Vector3(-checkDist, 0, checkDist).normalized * checkDist,
                    new Vector3(-checkDist, 0, -checkDist).normalized * checkDist,
                };

                foreach (Vector3 offset in offsets)
                {
                    Vector3 checkPos = node.Center + offset + Vector3.up * rayHeight;

                    if (!Physics.Raycast(checkPos, Vector3.down, rayLength,
                                          octree.ObstacleLayerMask,
                                          QueryTriggerInteraction.Ignore))
                    {
                        missingGround++; // Прірва в цьому напрямку
                    }
                }

                // 0/8 прірв = 0.0 (центр), 4/8 = 0.5 (кут), 8/8 = 1.0 (стовп)
                edgeProximity[node] = (float)missingGround / totalDirs;
            }

            int edgeCount = 0;
            foreach (var kv in edgeProximity)
                if (kv.Value > 0.1f) edgeCount++;

            Debug.Log($"[NavGraph] Edge proximity: {edgeCount} вокселів біля краю з {groundVoxels.Count}");
        }

        // =====================================================================
        //  ПОПЕРЕДНЯ ПОБУДОВА РЕБЕР
        // =====================================================================

        /// <summary>
        /// Обчислює всі ребра графа один раз при створенні.
        /// Після цього A* лише читає готові списки — 0 фізичних перевірок.
        /// </summary>
        private void PrecomputeAllEdges()
        {
            Stopwatch sw = Stopwatch.StartNew();

            int totalWalk = 0;
            int totalJump = 0;
            int totalFall = 0;

            foreach (VoxelNode node in groundVoxels.Values)
            {
                List<NavEdge> edges = new List<NavEdge>(8);

                BuildWalkEdges(node, edges);
                int walkCount = edges.Count;

                BuildJumpEdges(node, edges);

                foreach (NavEdge e in edges)
                {
                    if (e.Type == EdgeType.Walk) totalWalk++;
                    else if (e.Type == EdgeType.Jump) totalJump++;
                    else if (e.Type == EdgeType.Fall) totalFall++;
                }

                precomputedEdges[node] = edges;
            }

            sw.Stop();
            Debug.Log($"[NavGraph] Граф побудовано за {sw.ElapsedMilliseconds} мс. " +
                      $"Вузлів: {groundVoxels.Count}, " +
                      $"Walk: {totalWalk}, Jump: {totalJump}, Fall: {totalFall}");
        }

        // =====================================================================
        //  ОТРИМАННЯ СУСІДІВ (для A* — тільки читання)
        // =====================================================================

        /// <summary>
        /// Повертає попередньо обчислені ребра для вузла.
        /// Жодних фізичних перевірок — тільки читання зі словника.
        /// </summary>
        public List<NavEdge> GetNeighbors(VoxelNode node)
        {
            if (precomputedEdges.TryGetValue(node, out List<NavEdge> edges))
                return edges;

            return new List<NavEdge>();
        }

        // =====================================================================
        //  ПОБУДОВА WALK-РЕБЕР
        // =====================================================================

        private void BuildWalkEdges(VoxelNode node, List<NavEdge> edges)
        {
            float nodeSize = node.Size;
            float searchRadius = nodeSize * WalkNeighborRange;

            List<VoxelNode> nearby = walkGrid.GetNearby(node.Center, searchRadius);

            // Близькість поточного вокселя до краю
            float nodeEdgeProx = edgeProximity.TryGetValue(node, out float np) ? np : 0f;

            foreach (VoxelNode candidate in nearby)
            {
                if (candidate == node) continue;

                float verticalDist = Mathf.Abs(candidate.Center.y - node.Center.y);
                if (verticalDist > MaxWalkHeightDiff) continue;

                float maxWalkDist = (nodeSize + candidate.Size) * 0.5f * 1.5f;
                float horizontalDist = new Vector2(
                    candidate.Center.x - node.Center.x,
                    candidate.Center.z - node.Center.z).magnitude;
                if (horizontalDist > maxWalkDist) continue;

                if (!IsAgentClearanceFree(node.Center, candidate.Center))
                    continue;

                float distance = Vector3.Distance(node.Center, candidate.Center);

                // Базова вартість
                float cost = distance * WalkCostMultiplier;

                // Штраф "страху падіння": максимум з близькості обох вокселів.
                // Якщо хоча б один з них біля краю — перехід дорожчий.
                // cost *= 1 + FallFearMultiplier * max(nodeProx, candidateProx)
                float candidateEdgeProx = edgeProximity.TryGetValue(candidate, out float cp) ? cp : 0f;
                float maxProximity = Mathf.Max(nodeEdgeProx, candidateEdgeProx);
                cost *= 1f + FallFearMultiplier * maxProximity;

                edges.Add(NavEdge.CreateWalk(node, candidate, cost));
            }
        }

        /// <summary>
        /// Перевіряє, чи може капсула агента фізично пройти між двома точками.
        /// </summary>
        private bool IsAgentClearanceFree(Vector3 from, Vector3 to)
        {
            float radius = agentParams.radius;
            float footOffset = radius + 0.1f;
            float headOffset = agentParams.height - radius;

            Vector3 p1From = from + Vector3.up * footOffset;
            Vector3 p2From = from + Vector3.up * headOffset;

            Vector3 direction = to - from;
            direction.y = 0;
            float distance = direction.magnitude;

            if (distance < 0.01f) return true;

            if (Physics.CapsuleCast(
                p1From, p2From,
                radius * 0.9f,
                direction.normalized,
                distance,
                octree.ObstacleLayerMask,
                QueryTriggerInteraction.Ignore))
            {
                return false;
            }

            return true;
        }

        // =====================================================================
        //  ПОБУДОВА JUMP/FALL-РЕБЕР
        // =====================================================================

        private void BuildJumpEdges(VoxelNode node, List<NavEdge> edges)
        {
            float maxJumpDist = agentParams.MaxJumpDistance;
            float maxJumpHeight = agentParams.MaxJumpHeight;
            float halfHeight = agentParams.HalfHeight;

            float minJumpDist = node.Size * 2f;

            List<VoxelNode> nearby = jumpGrid.GetNearby(node.Center, maxJumpDist);

            foreach (VoxelNode candidate in nearby)
            {
                if (candidate == node) continue;

                Vector3 delta = candidate.Center - node.Center;
                float horizontalDist = new Vector2(delta.x, delta.z).magnitude;
                float verticalDist = delta.y;

                if (verticalDist > maxJumpHeight) continue;
                if (verticalDist < -MaxSafeFallHeight) continue;

                bool hasWalkEdge = false;
                foreach (NavEdge e in edges)
                {
                    if (e.To == candidate && e.Type == EdgeType.Walk)
                    {
                        hasWalkEdge = true;
                        break;
                    }
                }
                if (hasWalkEdge) continue;

                if (horizontalDist < minJumpDist && Mathf.Abs(verticalDist) <= MaxWalkHeightDiff)
                    continue;

                // --- Падіння ---
                if (verticalDist < -MaxWalkHeightDiff && horizontalDist < node.Size * 3f)
                {
                    // Перевіряємо чи шлях падіння вільний від перешкод (стін!)
                    Vector3 fallFrom = node.Center + Vector3.up * halfHeight;
                    Vector3 fallTo = candidate.Center + Vector3.up * halfHeight;
                    Vector3 fallDir = fallTo - fallFrom;
                    float fallDist = fallDir.magnitude;

                    if (fallDist > 0.01f)
                    {
                        float innerOffset = halfHeight - agentParams.radius;
                        Vector3 p1 = fallFrom - Vector3.up * innerOffset;
                        Vector3 p2 = fallFrom + Vector3.up * innerOffset;

                        if (Physics.CapsuleCast(p1, p2, agentParams.radius,
                                                 fallDir.normalized, fallDist,
                                                 octree.ObstacleLayerMask,
                                                 QueryTriggerInteraction.Ignore))
                        {
                            continue; // Стіна блокує падіння
                        }
                    }

                    float fallHeight = Mathf.Abs(verticalDist);
                    float fallTime = Mathf.Sqrt(2f * fallHeight / agentParams.gravity);
                    float fallCost = fallTime * FallCostMultiplier;

                    edges.Add(NavEdge.CreateFall(node, candidate, fallCost, fallTime));
                    continue;
                }

                // --- Стрибок ---
                // КЛЮЧОВИЙ ФІКС: зміщуємо позиції на halfHeight вгору.
                // Ground-воксель знаходиться на рівні поверхні (ноги агента).
                // Траєкторія має розраховуватися для ЦЕНТРУ КАПСУЛИ,
                // який на 0.9м вище поверхні.
                // Без цього агент цілить "ногами" в поверхню і врізається тілом.
                Vector3 jumpFrom = node.Center + Vector3.up * halfHeight;
                Vector3 jumpTo = candidate.Center + Vector3.up * halfHeight;

                if (jumpPhysics.TryJump(jumpFrom, jumpTo,
                                         out Vector3 launchVelocity, out float flightTime))
                {
                    float jumpCost = jumpPhysics.EstimateJumpCost(
                        jumpFrom, jumpTo, launchVelocity, flightTime);

                    edges.Add(NavEdge.CreateJump(node, candidate, jumpCost,
                                                  launchVelocity, flightTime));
                }
            }
        }

        // =====================================================================
        //  ДОПОМІЖНІ МЕТОДИ
        // =====================================================================

        public VoxelNode FindNearestGroundVoxel(Vector3 worldPosition)
        {
            for (float radius = 2f; radius <= 20f; radius += 3f)
            {
                List<VoxelNode> nearby = walkGrid.GetNearby(worldPosition, radius);
                if (nearby.Count > 0)
                {
                    VoxelNode nearest = null;
                    float minDist = float.MaxValue;
                    foreach (VoxelNode node in nearby)
                    {
                        float dist = Vector3.Distance(node.Center, worldPosition);
                        if (dist < minDist)
                        {
                            minDist = dist;
                            nearest = node;
                        }
                    }
                    return nearest;
                }
            }
            return null;
        }

        public VoxelNode FindNearestGroundVoxel(Vector3 worldPosition, float maxRadius)
        {
            List<VoxelNode> nearby = walkGrid.GetNearby(worldPosition, maxRadius);
            VoxelNode nearest = null;
            float minDist = maxRadius;

            foreach (VoxelNode node in nearby)
            {
                float dist = Vector3.Distance(node.Center, worldPosition);
                if (dist < minDist)
                {
                    minDist = dist;
                    nearest = node;
                }
            }
            return nearest;
        }
    }
}