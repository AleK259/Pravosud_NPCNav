using System.Diagnostics;
using UnityEngine;
using UnityEngine.AI;
using Debug = UnityEngine.Debug;

namespace Navigation.Comparison
{
    /// <summary>
    /// Обгортка для тестування стандартного Unity NavMesh.
    /// 
    /// Вимірює час пошуку шляху, довжину маршруту та success rate.
    /// Також фіксує, чи потребує NavMesh ручних Off-Mesh Links.
    /// 
    /// Вимоги:
    /// - Навігаційна сітка має бути побудована (Window → AI → Navigation → Bake)
    /// - На NPC має бути компонент NavMeshAgent
    /// </summary>
    [RequireComponent(typeof(NavMeshAgent))]
    public class NavMeshBenchmark : MonoBehaviour
    {
        [Header("Ціль")]
        [SerializeField] private Transform goalPoint;

        [Header("Налаштування бенчмарку")]
        [SerializeField] private int benchmarkRuns = 10;

        [Header("Результати (read-only)")]
        [SerializeField] private float lastSearchTimeMs;
        [SerializeField] private float lastPathLength;
        [SerializeField] private bool lastPathFound;
        [SerializeField] private int lastPathCorners;

        private NavMeshAgent agent;
        private NavMeshPath calculatedPath;

        [Header("Автозапуск")]
        [SerializeField] private bool autoStart = true;
        [SerializeField] private float startDelay = 1.0f;

        private void Awake()
        {
            agent = GetComponent<NavMeshAgent>();
            calculatedPath = new NavMeshPath();
        }

        private void Start()
        {
            if (autoStart && goalPoint != null)
            {
                Invoke(nameof(MoveToGoal), startDelay);
            }
        }

        /// <summary>
        /// Обчислює шлях до цілі через NavMesh і вимірює час.
        /// </summary>
        [ContextMenu("Знайти шлях (NavMesh)")]
        public void FindPath()
        {
            if (goalPoint == null)
            {
                Debug.LogError("[NavMeshBenchmark] GoalPoint не призначений!");
                return;
            }

            Stopwatch sw = Stopwatch.StartNew();

            // Обчислюємо шлях без переміщення агента
            lastPathFound = NavMesh.CalculatePath(
                transform.position,
                goalPoint.position,
                NavMesh.AllAreas,
                calculatedPath
            );

            sw.Stop();
            lastSearchTimeMs = (float)sw.Elapsed.TotalMilliseconds;

            if (lastPathFound && calculatedPath.status == NavMeshPathStatus.PathComplete)
            {
                lastPathCorners = calculatedPath.corners.Length;
                lastPathLength = CalculatePathLength(calculatedPath.corners);

                Debug.Log($"[NavMesh] Шлях знайдено! " +
                          $"Час: {lastSearchTimeMs:F3} мс, " +
                          $"Вузлів: {lastPathCorners}, " +
                          $"Довжина: {lastPathLength:F2} м, " +
                          $"Статус: {calculatedPath.status}");
            }
            else
            {
                lastPathCorners = 0;
                lastPathLength = 0f;

                string statusStr = lastPathFound ? calculatedPath.status.ToString() : "NotFound";

                Debug.LogWarning($"[NavMesh] Шлях НЕ знайдено! " +
                                 $"Час: {lastSearchTimeMs:F3} мс, " +
                                 $"Статус: {statusStr}");
            }
        }

        /// <summary>
        /// Запускає агента до цілі (реальний рух).
        /// </summary>
        [ContextMenu("Рухатися до цілі (NavMesh)")]
        public void MoveToGoal()
        {
            if (goalPoint == null) return;

            agent.SetDestination(goalPoint.position);
            Debug.Log("[NavMesh] Агент рухається до цілі...");
        }

        /// <summary>
        /// Запускає бенчмарк: N пошуків з вимірюванням часу.
        /// </summary>
        [ContextMenu("Бенчмарк (NavMesh)")]
        public void RunBenchmark()
        {
            if (goalPoint == null)
            {
                Debug.LogError("[NavMeshBenchmark] GoalPoint не призначений!");
                return;
            }

            float totalTime = 0f;
            int successCount = 0;
            float totalLength = 0f;

            NavMeshPath tempPath = new NavMeshPath();

            for (int i = 0; i < benchmarkRuns; i++)
            {
                Stopwatch sw = Stopwatch.StartNew();

                bool found = NavMesh.CalculatePath(
                    transform.position,
                    goalPoint.position,
                    NavMesh.AllAreas,
                    tempPath
                );

                sw.Stop();
                totalTime += (float)sw.Elapsed.TotalMilliseconds;

                if (found && tempPath.status == NavMeshPathStatus.PathComplete)
                {
                    successCount++;
                    totalLength += CalculatePathLength(tempPath.corners);
                }
            }

            float avgTime = totalTime / benchmarkRuns;
            float avgLength = successCount > 0 ? totalLength / successCount : 0f;

            Debug.Log(
                $"=== БЕНЧМАРК NavMesh ({benchmarkRuns} запусків) ===\n" +
                $"Середній час: {avgTime:F3} мс\n" +
                $"Успішних: {successCount}/{benchmarkRuns}\n" +
                $"Середня довжина: {avgLength:F2} м\n" +
                $"Загальний час: {totalTime:F3} мс"
            );
        }

        private float CalculatePathLength(Vector3[] corners)
        {
            if (corners == null || corners.Length < 2) return 0f;

            float length = 0f;
            for (int i = 1; i < corners.Length; i++)
            {
                length += Vector3.Distance(corners[i - 1], corners[i]);
            }
            return length;
        }

        // =====================================================================
        //  ВІЗУАЛІЗАЦІЯ
        // =====================================================================

        private void OnDrawGizmosSelected()
        {
            if (calculatedPath == null || calculatedPath.corners == null) return;
            if (calculatedPath.corners.Length < 2) return;

            // Маршрут NavMesh — блакитний
            Gizmos.color = Color.cyan;
            for (int i = 0; i < calculatedPath.corners.Length; i++)
            {
                Gizmos.DrawSphere(calculatedPath.corners[i], 0.2f);

                if (i > 0)
                {
                    Gizmos.DrawLine(calculatedPath.corners[i - 1], calculatedPath.corners[i]);
                }
            }
        }
    }
}