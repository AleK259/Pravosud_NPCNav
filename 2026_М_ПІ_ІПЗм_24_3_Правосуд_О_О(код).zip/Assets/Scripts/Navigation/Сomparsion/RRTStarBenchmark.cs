using System.Collections.Generic;
using UnityEngine;

namespace Navigation.Comparison
{
    /// <summary>
    /// MonoBehaviour обгортка для RRT* з візуалізацією та бенчмарком.
    /// Прикріплюється до порожнього GameObject у сцені.
    /// </summary>
    public class RRTStarBenchmark : MonoBehaviour
    {
        [Header("Точки маршруту")]
        [SerializeField] private Transform startPoint;
        [SerializeField] private Transform goalPoint;

        [Header("Параметри RRT*")]
        [SerializeField] private int maxIterations = 5000;
        [SerializeField] private float stepSize = 1.0f;
        [SerializeField] private float goalRadius = 1.0f;
        [SerializeField] private float rewireRadius = 3.0f;
        [SerializeField] private float agentRadius = 0.3f;
        [SerializeField] private float agentHeight = 1.8f;
        [SerializeField] private float maxJumpSpeed = 10f;
        [Range(0f, 0.3f)]
        [SerializeField] private float goalBias = 0.15f;

        [Header("Шари перешкод")]
        [SerializeField] private LayerMask obstacleLayers = ~0;

        [Header("Бенчмарк")]
        [SerializeField] private int benchmarkRuns = 10;

        [Header("Візуалізація")]
        [SerializeField] private bool showTree = true;
        [SerializeField] private bool showPath = true;
        [SerializeField] private Color treeColor = new Color(0.3f, 0.3f, 1f, 0.15f);
        [SerializeField] private Color pathColor = new Color(1f, 0f, 1f, 1f); // Фіолетовий

        [Header("Результати (read-only)")]
        [SerializeField] private float lastSearchTimeMs;
        [SerializeField] private float lastPathLength;
        [SerializeField] private bool lastPathFound;
        [SerializeField] private int lastTreeNodes;

        private RRTStarPathfinder pathfinder;
        private List<Vector3> lastPath;
        private List<RRTStarPathfinder.RRTNode> lastTreeNodes_list;

        /// <summary>
        /// Запускає пошук шляху RRT*.
        /// </summary>
        [ContextMenu("Знайти шлях (RRT*)")]
        public void FindPath()
        {
            if (startPoint == null || goalPoint == null)
            {
                Debug.LogError("[RRT*] StartPoint або GoalPoint не призначені!");
                return;
            }

            pathfinder = new RRTStarPathfinder
            {
                MaxIterations = maxIterations,
                StepSize = stepSize,
                GoalRadius = goalRadius,
                RewireRadius = rewireRadius,
                AgentRadius = agentRadius,
                AgentHeight = agentHeight,
                MaxJumpSpeed = maxJumpSpeed,
                GoalBias = goalBias,
                ObstacleMask = obstacleLayers
            };

            lastPath = pathfinder.FindPath(startPoint.position, goalPoint.position);

            lastSearchTimeMs = pathfinder.LastSearchTimeMs;
            lastPathFound = pathfinder.LastSuccess;
            lastTreeNodes = pathfinder.AllNodes.Count;
            lastPathLength = pathfinder.GetPathLength();
            lastTreeNodes_list = pathfinder.AllNodes;

            if (lastPathFound)
            {
                Debug.Log($"[RRT*] Шлях знайдено! " +
                          $"Час: {lastSearchTimeMs:F2} мс, " +
                          $"Вузлів дерева: {lastTreeNodes}, " +
                          $"Точок шляху: {lastPath.Count}, " +
                          $"Довжина: {lastPathLength:F2} м");
            }
            else
            {
                Debug.LogWarning($"[RRT*] Шлях НЕ знайдено! " +
                                 $"Час: {lastSearchTimeMs:F2} мс, " +
                                 $"Вузлів дерева: {lastTreeNodes}");
            }
        }

        /// <summary>
        /// Запускає бенчмарк: N пошуків з вимірюванням часу.
        /// </summary>
        [ContextMenu("Бенчмарк (RRT*)")]
        public void RunBenchmark()
        {
            if (startPoint == null || goalPoint == null)
            {
                Debug.LogError("[RRT*] StartPoint або GoalPoint не призначені!");
                return;
            }

            float totalTime = 0f;
            int successCount = 0;
            float totalLength = 0f;
            int totalNodes = 0;

            for (int i = 0; i < benchmarkRuns; i++)
            {
                RRTStarPathfinder pf = new RRTStarPathfinder
                {
                    MaxIterations = maxIterations,
                    StepSize = stepSize,
                    GoalRadius = goalRadius,
                    RewireRadius = rewireRadius,
                    AgentRadius = agentRadius,
                    GoalBias = goalBias,
                    ObstacleMask = obstacleLayers
                };

                pf.FindPath(startPoint.position, goalPoint.position);

                totalTime += pf.LastSearchTimeMs;
                totalNodes += pf.AllNodes.Count;

                if (pf.LastSuccess)
                {
                    successCount++;
                    totalLength += pf.GetPathLength();
                }
            }

            float avgTime = totalTime / benchmarkRuns;
            float avgLength = successCount > 0 ? totalLength / successCount : 0f;
            float avgNodes = (float)totalNodes / benchmarkRuns;

            Debug.Log(
                $"=== БЕНЧМАРК RRT* ({benchmarkRuns} запусків) ===\n" +
                $"Середній час: {avgTime:F2} мс\n" +
                $"Успішних: {successCount}/{benchmarkRuns}\n" +
                $"Середня довжина: {avgLength:F2} м\n" +
                $"Середня кількість вузлів дерева: {avgNodes:F0}\n" +
                $"Загальний час: {totalTime:F2} мс"
            );
        }

        // =====================================================================
        //  ВІЗУАЛІЗАЦІЯ
        // =====================================================================

        private void OnDrawGizmosSelected()
        {
            // Дерево RRT*
            if (showTree && lastTreeNodes_list != null)
            {
                Gizmos.color = treeColor;
                foreach (var node in lastTreeNodes_list)
                {
                    if (node.Parent != null)
                    {
                        Gizmos.DrawLine(node.Position, node.Parent.Position);
                    }
                }
            }

            // Знайдений шлях
            if (showPath && lastPath != null && lastPath.Count >= 2)
            {
                Gizmos.color = pathColor;
                for (int i = 0; i < lastPath.Count; i++)
                {
                    Gizmos.DrawSphere(lastPath[i], 0.2f);

                    if (i > 0)
                    {
                        Gizmos.DrawLine(lastPath[i - 1], lastPath[i]);
                    }
                }
            }

            // Старт і ціль
            if (startPoint != null)
            {
                Gizmos.color = Color.green;
                Gizmos.DrawWireSphere(startPoint.position, 0.5f);
            }

            if (goalPoint != null)
            {
                Gizmos.color = Color.red;
                Gizmos.DrawWireSphere(goalPoint.position, 0.5f);
            }
        }

        // =====================================================================
        //  ПУБЛІЧНІ МЕТОДИ (для RRTAgent)
        // =====================================================================

        public bool LastPathFound() => lastPathFound;
        public List<Vector3> GetLastPath() => lastPath;
    }
}