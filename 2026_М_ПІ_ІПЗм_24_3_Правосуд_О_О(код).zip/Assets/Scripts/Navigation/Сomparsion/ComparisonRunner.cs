using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Profiling;
using Navigation.Voxelization;
using Debug = UnityEngine.Debug;

namespace Navigation.Comparison
{
    /// <summary>
    /// Порівняльний аналіз трьох алгоритмів навігації.
    /// 
    /// Особливості:
    /// 1. Випадково обирає пари старт/ціль з Ground-вокселів
    /// 2. Валідує маршрути: перевіряє чи кожен сегмент фізично прохідний
    /// 3. Виводить зведену таблицю з реальними метриками
    /// </summary>
    public class ComparisonRunner : MonoBehaviour
    {
        [Header("Посилання")]
        [SerializeField] private NavigationManager svoNavigationManager;
        [SerializeField] private SceneVoxelizer sceneVoxelizer;

        [Header("Параметри тестування")]
        [Tooltip("Кількість випадкових пар старт/ціль")]
        [SerializeField] private int testPairs = 10;

        [Tooltip("Кількість повторів кожної пари (для стабілізації часу)")]
        [SerializeField] private int runsPerPair = 3;

        [Tooltip("Мінімальна відстань між стартом та ціллю (метри)")]
        [SerializeField] private float minDistance = 5f;

        [Header("Параметри агента")]
        [SerializeField] private float agentRadius = 0.3f;
        [SerializeField] private float agentHeight = 1.8f;

        [Header("RRT* параметри")]
        [SerializeField] private int rrtMaxIterations = 5000;
        [SerializeField] private float rrtStepSize = 1.5f;
        [SerializeField] private float rrtMaxJumpSpeed = 10f;

        [Header("Шари")]
        [SerializeField] private LayerMask obstacleLayers = ~0;

        private List<VoxelNode> groundVoxelList;

        // =====================================================================
        //  ГЕНЕРАЦІЯ ВИПАДКОВИХ ПАР
        // =====================================================================

        private List<(Vector3 start, Vector3 goal)> GenerateRandomPairs(int count)
        {
            if (groundVoxelList == null || groundVoxelList.Count < 2)
            {
                Debug.LogError("[Comparison] Недостатньо Ground-вокселів!");
                return new List<(Vector3, Vector3)>();
            }

            var pairs = new List<(Vector3, Vector3)>();
            int attempts = 0;

            while (pairs.Count < count && attempts < count * 20)
            {
                attempts++;
                VoxelNode s = groundVoxelList[Random.Range(0, groundVoxelList.Count)];
                VoxelNode g = groundVoxelList[Random.Range(0, groundVoxelList.Count)];
                if (s == g) continue;
                if (Vector3.Distance(s.Center, g.Center) < minDistance) continue;
                pairs.Add((s.Center, g.Center));
            }

            Debug.Log($"[Comparison] Згенеровано {pairs.Count} пар з {groundVoxelList.Count} вокселів");
            return pairs;
        }

        // =====================================================================
        //  ВАЛІДАЦІЯ МАРШРУТУ
        // =====================================================================

        private (bool valid, string reason) ValidatePath(List<Vector3> path)
        {
            if (path == null || path.Count < 2)
                return (false, "Порожній маршрут");

            for (int i = 0; i < path.Count; i++)
            {
                Vector3 point = path[i];

                // Земля під точкою — SphereCast щоб покрити край платформи
                if (!Physics.SphereCast(point + Vector3.up * 2f, agentRadius, Vector3.down,
                                         out RaycastHit _, 5f, obstacleLayers,
                                         QueryTriggerInteraction.Ignore))
                    return (false, $"Точка {i} у повітрі");

                // Danger
                Collider[] cols = Physics.OverlapSphere(point, agentRadius);
                foreach (Collider c in cols)
                    if (c.isTrigger && c.CompareTag("Danger"))
                        return (false, $"Точка {i} у Danger");

                // Перевірка сегменту
                if (i < path.Count - 1)
                {
                    Vector3 next = path[i + 1];
                    float vDiff = Mathf.Abs(next.y - point.y);

                    // Визначаємо чи сегмент перетинає прірву (немає землі посередині)
                    bool hasGap = HasGapBetween(point, next);

                    // Якщо перепад висоти > 0.5м або є прірва — це стрибок/link, пропускаємо
                    if (vDiff > 0.5f || hasGap) continue;

                    // Walk-сегмент: CapsuleCast
                    Vector3 dir = next - point;
                    dir.y = 0;
                    float d = dir.magnitude;
                    if (d < 0.1f) continue;

                    Vector3 p1 = point + Vector3.up * (agentRadius + 0.1f);
                    Vector3 p2 = point + Vector3.up * (agentHeight - agentRadius);

                    if (Physics.CapsuleCast(p1, p2, agentRadius * 0.9f,
                        dir.normalized, d, obstacleLayers, QueryTriggerInteraction.Ignore))
                        return (false, $"Сегмент {i}→{i + 1} заблокований");
                }
            }

            return (true, "OK");
        }

        /// <summary>
        /// Перевіряє чи є прірва (відсутність землі) між двома точками.
        /// Кидає 3 промені вниз вздовж сегменту.
        /// </summary>
        private bool HasGapBetween(Vector3 from, Vector3 to)
        {
            for (int j = 1; j <= 3; j++)
            {
                float t = j / 4f;
                Vector3 mid = Vector3.Lerp(from, to, t) + Vector3.up * 1.5f;

                if (!Physics.Raycast(mid, Vector3.down, 4f,
                                      obstacleLayers, QueryTriggerInteraction.Ignore))
                {
                    return true; // Знайдено прірву
                }
            }
            return false;
        }

        // =====================================================================
        //  ТЕСТИ
        // =====================================================================

        private AlgResult TestSVO(List<(Vector3 start, Vector3 goal)> pairs)
        {
            var r = new AlgResult { Name = "SVO+A*" };

            if (svoNavigationManager == null || !svoNavigationManager.IsReady)
            { r.Error = "Не готовий"; return r; }

            // Пам'ять: вимірюємо постійні структури (октодерево + граф)
            r.MemoryBytes = MeasureSVOMemory();

            foreach (var (start, goal) in pairs)
            {
                float time = 0f;
                bool found = false;
                float len = 0f;
                int iters = 0;
                bool valid = false;

                for (int run = 0; run < runsPerPair; run++)
                {
                    PathResult pr = svoNavigationManager.FindPath(start, goal);
                    if (pr == null) continue;

                    time += pr.SearchTimeMs;
                    iters += pr.IterationCount;

                    if (pr.IsSuccess && run == 0)
                    {
                        found = true;
                        len = pr.TotalDistance;
                        var (v, _) = ValidatePath(pr.GetPositions().ToList());
                        valid = v;
                    }
                }

                r.TotalPairs++;
                r.TotalTimeMs += time / runsPerPair;
                r.TotalIterations += iters / runsPerPair;
                if (found) { r.FoundCount++; r.TotalLength += len; }
                if (valid)
                {
                    r.ValidCount++;
                    PathResult prCost = svoNavigationManager.FindPath(start, goal);
                    if (prCost != null && prCost.IsSuccess)
                        r.TotalSafetyCost += PathCostEvaluator.Evaluate(
                            new List<Vector3>(prCost.GetPositions()), obstacleLayers);
                }
            }
            return r;
        }

        private AlgResult TestNavMesh(List<(Vector3 start, Vector3 goal)> pairs)
        {
            var r = new AlgResult { Name = "NavMesh" };

            NavMeshHit hit;
            if (!NavMesh.SamplePosition(pairs[0].start, out hit, 5f, NavMesh.AllAreas))
            { r.Error = "Не побудований"; return r; }

            // Пам'ять: NavMesh — нативна пам'ять Unity
            NavMeshTriangulation tri = NavMesh.CalculateTriangulation();
            r.MemoryBytes = (long)tri.vertices.Length * 12L  // Vector3 = 12 bytes
                          + (long)tri.indices.Length * 4L    // int = 4 bytes
                          + (long)tri.areas.Length * 4L;     // int = 4 bytes

            NavMeshPath temp = new NavMeshPath();

            foreach (var (start, goal) in pairs)
            {
                float time = 0f;
                bool found = false;
                float len = 0f;
                int corners = 0;
                bool valid = false;

                for (int run = 0; run < runsPerPair; run++)
                {
                    Stopwatch sw = Stopwatch.StartNew();
                    bool ok = NavMesh.CalculatePath(start, goal, NavMesh.AllAreas, temp);
                    sw.Stop();
                    time += (float)sw.Elapsed.TotalMilliseconds;

                    if (ok && temp.status == NavMeshPathStatus.PathComplete && run == 0)
                    {
                        found = true;
                        corners = temp.corners.Length;
                        len = 0f;
                        for (int j = 1; j < temp.corners.Length; j++)
                            len += Vector3.Distance(temp.corners[j - 1], temp.corners[j]);
                        var (v, _) = ValidatePath(new List<Vector3>(temp.corners));
                        valid = v;
                    }
                }

                r.TotalPairs++;
                r.TotalTimeMs += time / runsPerPair;
                r.TotalIterations += corners;
                if (found) { r.FoundCount++; r.TotalLength += len; }
                if (valid)
                {
                    r.ValidCount++;
                    NavMeshPath costPath = new NavMeshPath();
                    if (NavMesh.CalculatePath(start, goal, NavMesh.AllAreas, costPath)
                        && costPath.status == NavMeshPathStatus.PathComplete)
                        r.TotalSafetyCost += PathCostEvaluator.Evaluate(
                            new List<Vector3>(costPath.corners), obstacleLayers);
                }
            }
            return r;
        }

        private AlgResult TestRRT(List<(Vector3 start, Vector3 goal)> pairs)
        {
            var r = new AlgResult { Name = "RRT*" };
            long peakMemory = 0;

            foreach (var (start, goal) in pairs)
            {
                float time = 0f;
                bool found = false;
                float len = 0f;
                int nodes = 0;
                bool valid = false;

                for (int run = 0; run < runsPerPair; run++)
                {
                    // Вимірюємо пам'ять дерева RRT*
                    long memBefore = System.GC.GetTotalMemory(false);

                    var pf = new RRTStarPathfinder
                    {
                        MaxIterations = rrtMaxIterations,
                        StepSize = rrtStepSize,
                        AgentRadius = agentRadius,
                        AgentHeight = agentHeight,
                        MaxJumpSpeed = rrtMaxJumpSpeed,
                        ObstacleMask = obstacleLayers
                    };

                    pf.FindPath(start, goal);

                    long memAfter = System.GC.GetTotalMemory(false);
                    long memDelta = memAfter - memBefore;
                    if (memDelta > peakMemory) peakMemory = memDelta;

                    time += pf.LastSearchTimeMs;
                    nodes += pf.AllNodes.Count;

                    if (pf.LastSuccess && run == 0)
                    {
                        found = true;
                        len = pf.GetPathLength();
                        var (v, _) = ValidatePath(pf.LastPath);
                        valid = v;
                    }
                }

                r.TotalPairs++;
                r.TotalTimeMs += time / runsPerPair;
                r.TotalIterations += nodes / runsPerPair;
                if (found) { r.FoundCount++; r.TotalLength += len; }
                if (valid)
                {
                    r.ValidCount++;
                    // Перерахуємо шлях для вартості
                    var pfCost = new RRTStarPathfinder
                    {
                        MaxIterations = rrtMaxIterations, StepSize = rrtStepSize,
                        AgentRadius = agentRadius, AgentHeight = agentHeight,
                        MaxJumpSpeed = rrtMaxJumpSpeed, ObstacleMask = obstacleLayers
                    };
                    pfCost.FindPath(start, goal);
                    if (pfCost.LastSuccess)
                        r.TotalSafetyCost += PathCostEvaluator.Evaluate(pfCost.LastPath, obstacleLayers);
                }
            }
            r.MemoryBytes = peakMemory;
            return r;
        }

        // =====================================================================
        //  ВИМІРЮВАННЯ ПАМ'ЯТІ
        // =====================================================================

        /// <summary>
        /// Оцінює пам'ять, зайняту октодеревом та навігаційним графом.
        /// Використовує Profiler для нативних об'єктів та оцінку
        /// за кількістю вузлів/ребер для managed-структур.
        /// </summary>
        private long MeasureSVOMemory()
        {
            long total = 0;

            // Октодерево: кожен VoxelNode ≈ 80 байт (Center, Size, Type, MortonCode, посилання)
            if (sceneVoxelizer != null && sceneVoxelizer.IsBuilt)
            {
                var groundVoxels = sceneVoxelizer.GetGroundVoxels();
                long voxelCount = groundVoxels.Count;
                total += voxelCount * 80;

                // Словник GroundVoxels: ключ uint(4) + значення ref(8) + overhead(24) ≈ 36 per entry
                total += voxelCount * 36;
            }

            // Навігаційний граф: ребра
            // Кожне NavEdge ≈ 64 байт (From, To, Type, Cost, LaunchVelocity, FlightTime)
            // Словник adjacency: ключ ref(8) + List ref(8) + List overhead(40) per node
            if (svoNavigationManager != null && svoNavigationManager.IsReady)
            {
                long groundCount = groundVoxelList != null ? groundVoxelList.Count : 0;
                // В середньому ~6 ребер на вузол (4 walk + 1-2 jump/fall)
                long estimatedEdges = groundCount * 6;
                total += estimatedEdges * 64;
                total += groundCount * 56; // adjacency dictionary overhead

                // SpatialHashGrid: по 2 grid (walk, jump), кожна комірка ≈ 48 байт
                total += groundCount * 48 * 2;

                // EdgeProximity dictionary: float(4) per ground node + overhead
                total += groundCount * 28;
            }

            return total;
        }

        // =====================================================================
        //  ЗАПУСК
        // =====================================================================

        [ContextMenu("Запустити повне порівняння")]
        public void RunFullComparison()
        {
            if (sceneVoxelizer == null || !sceneVoxelizer.IsBuilt)
            { Debug.LogError("[Comparison] SceneVoxelizer не побудований!"); return; }

            groundVoxelList = new List<VoxelNode>(sceneVoxelizer.GetGroundVoxels().Values);
            if (groundVoxelList.Count < 2)
            { Debug.LogError("[Comparison] Недостатньо Ground-вокселів!"); return; }

            var pairs = GenerateRandomPairs(testPairs);
            if (pairs.Count == 0) return;

            Debug.Log("══════════════════════════════════════════════════════════");
            Debug.Log("         ПОРІВНЯЛЬНИЙ АНАЛІЗ АЛГОРИТМІВ НАВІГАЦІЇ");
            Debug.Log($"         Пар: {pairs.Count}, Повторів: {runsPerPair}");
            Debug.Log("══════════════════════════════════════════════════════════\n");

            AlgResult svo = TestSVO(pairs);
            AlgResult nav = TestNavMesh(pairs);
            AlgResult rrt = TestRRT(pairs);

            PrintTable(svo, nav, rrt);
        }

        [ContextMenu("Тест тільки SVO+A*")]
        public void TestSVOOnly()
        {
            Init();
            var p = GenerateRandomPairs(testPairs);
            if (p.Count > 0) { var r = TestSVO(p); PrintSingle(r); }
        }

        [ContextMenu("Тест тільки NavMesh")]
        public void TestNavMeshOnly()
        {
            Init();
            var p = GenerateRandomPairs(testPairs);
            if (p.Count > 0) { var r = TestNavMesh(p); PrintSingle(r); }
        }

        [ContextMenu("Тест тільки RRT*")]
        public void TestRRTOnly()
        {
            Init();
            var p = GenerateRandomPairs(testPairs);
            if (p.Count > 0) { var r = TestRRT(p); PrintSingle(r); }
        }

        private void Init()
        {
            if (sceneVoxelizer != null && sceneVoxelizer.IsBuilt)
                groundVoxelList = new List<VoxelNode>(sceneVoxelizer.GetGroundVoxels().Values);
        }

        private void PrintSingle(AlgResult r)
        {
            Debug.Log($"[{r.Name}] Час: {r.AvgTime:F2}мс, " +
                      $"Знайдено: {r.FoundRate:F0}%, " +
                      $"Валідних: {r.ValidRate:F0}%, " +
                      $"Довжина: {r.AvgLength:F2}м");
        }

        // =====================================================================
        //  ТАБЛИЦЯ
        // =====================================================================

        private void PrintTable(AlgResult svo, AlgResult nav, AlgResult rrt)
        {
            string sep = "──────────────────────────────────────────────────────────────";

            Debug.Log("\n" + sep);
            Debug.Log("                  ЗВЕДЕНА ТАБЛИЦЯ ПОРІВНЯННЯ");
            Debug.Log(sep);

            Debug.Log(string.Format("{0,-30} {1,-16} {2,-16} {3,-16}",
                "Критерій", "SVO+A*", "NavMesh", "RRT*"));
            Debug.Log(sep);

            Row("Серед. час пошуку (мс)", svo, nav, rrt,
                r => r.Error ?? $"{r.AvgTime:F2}");

            Row("Шлях знайдено (%)", svo, nav, rrt,
                r => r.Error ?? $"{r.FoundRate:F0}%");

            Row("Серед. довжина (м)", svo, nav, rrt,
                r => r.Error ?? $"{r.AvgLength:F2}");

            Row("Серед. ітерації/вузли", svo, nav, rrt,
                r => r.Error ?? $"{r.AvgIter:F0}");

            Row("Серед. вартість (безпека)", svo, nav, rrt,
                r => r.Error ?? (r.ValidCount > 0 ? $"{r.AvgSafetyCost:F1}" : "N/A"));

            Row("Пам'ять (RAM)", svo, nav, rrt,
                r => r.Error ?? r.MemoryFormatted);

            Debug.Log(sep);
            Debug.Log("Шлях знайдено — алгоритм повернув маршрут");
            Debug.Log("Валідний шлях — маршрут пройшов перевірку CapsuleCast");
            Debug.Log("Пам'ять — SVO: октодерево+граф, NavMesh: тріангуляція, RRT*: пік дерева\n");
        }

        private void Row(string label, AlgResult a, AlgResult b, AlgResult c,
                          System.Func<AlgResult, string> fmt)
        {
            Debug.Log(string.Format("{0,-30} {1,-16} {2,-16} {3,-16}",
                label, fmt(a), fmt(b), fmt(c)));
        }

        // =====================================================================
        //  РЕЗУЛЬТАТ
        // =====================================================================

        private class AlgResult
        {
            public string Name;
            public string Error;
            public int TotalPairs;
            public float TotalTimeMs;
            public int FoundCount;
            public int ValidCount;
            public float TotalLength;
            public int TotalIterations;
            public float TotalSafetyCost;
            public long MemoryBytes;

            public float AvgTime => TotalPairs > 0 ? TotalTimeMs / TotalPairs : 0;
            public float FoundRate => TotalPairs > 0 ? (float)FoundCount / TotalPairs * 100 : 0;
            public float ValidRate => TotalPairs > 0 ? (float)ValidCount / TotalPairs * 100 : 0;
            public float AvgLength => FoundCount > 0 ? TotalLength / FoundCount : 0;
            public float AvgIter => TotalPairs > 0 ? (float)TotalIterations / TotalPairs : 0;
            public float AvgSafetyCost => ValidCount > 0 ? TotalSafetyCost / ValidCount : 0;
            public string MemoryFormatted => FormatBytes(MemoryBytes);

            private static string FormatBytes(long bytes)
            {
                if (bytes <= 0) return "N/A";
                if (bytes < 1024) return $"{bytes} B";
                if (bytes < 1024 * 1024) return $"{bytes / 1024f:F1} KB";
                return $"{bytes / (1024f * 1024f):F2} MB";
            }
        }
    }
}