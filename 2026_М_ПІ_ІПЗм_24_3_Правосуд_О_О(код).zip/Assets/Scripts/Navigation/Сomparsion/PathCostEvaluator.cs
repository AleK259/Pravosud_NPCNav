using System.Collections.Generic;
using UnityEngine;

namespace Navigation.Comparison
{
    /// <summary>
    /// Обчислює цільову функцію вартості маршруту з урахуванням безпеки.
    /// 
    /// F(path) = Σ( distance_i × (1 + w_edge × edgeProximity_i + w_danger × dangerProximity_i) )
    /// 
    /// де:
    /// - distance_i — довжина i-го сегменту
    /// - edgeProximity_i — близькість до краю платформи (0-1)
    /// - dangerProximity_i — близькість до Danger-зони (0-1)
    /// - w_edge, w_danger — вагові коефіцієнти
    /// 
    /// Менша вартість = безпечніший маршрут.
    /// Однакова формула для всіх трьох алгоритмів — справедливе порівняння.
    /// </summary>
    public static class PathCostEvaluator
    {
        /// <summary>Вага близькості до краю.</summary>
        public static float EdgeWeight = 2.0f;

        /// <summary>Вага близькості до небезпечної зони.</summary>
        public static float DangerWeight = 5.0f;

        /// <summary>Радіус пошуку Danger-зон (метри).</summary>
        public static float DangerSearchRadius = 3.0f;

        /// <summary>
        /// Обчислює цільову функцію вартості маршруту.
        /// </summary>
        /// <param name="path">Список точок маршруту</param>
        /// <param name="obstacleMask">Маска перешкод для raycast</param>
        /// <returns>Вартість маршруту (менше = краще)</returns>
        public static float Evaluate(List<Vector3> path, LayerMask obstacleMask)
        {
            if (path == null || path.Count < 2) return float.MaxValue;

            float totalCost = 0f;

            for (int i = 1; i < path.Count; i++)
            {
                Vector3 from = path[i - 1];
                Vector3 to = path[i];

                // Довжина сегменту
                float segmentLength = Vector3.Distance(from, to);

                // Середня точка сегменту для оцінки небезпеки
                Vector3 midPoint = (from + to) * 0.5f;

                // Близькість до краю платформи (edge proximity)
                float edgeProx = ComputeEdgeProximity(midPoint, obstacleMask);

                // Близькість до Danger-зони
                float dangerProx = ComputeDangerProximity(midPoint);

                // Вартість сегменту з урахуванням безпеки
                float safetyCost = 1f + EdgeWeight * edgeProx + DangerWeight * dangerProx;
                totalCost += segmentLength * safetyCost;
            }

            return totalCost;
        }

        /// <summary>
        /// Обчислює близькість точки до краю платформи (0 = центр, 1 = край).
        /// 4 промені в горизонтальних напрямках.
        /// </summary>
        private static float ComputeEdgeProximity(Vector3 point, LayerMask mask)
        {
            float checkDist = 1.0f;
            int missing = 0;

            Vector3[] offsets = {
                new Vector3(checkDist, 0, 0),
                new Vector3(-checkDist, 0, 0),
                new Vector3(0, 0, checkDist),
                new Vector3(0, 0, -checkDist)
            };

            foreach (Vector3 offset in offsets)
            {
                Vector3 checkPos = point + offset + Vector3.up * 1.5f;
                if (!Physics.Raycast(checkPos, Vector3.down, 3f,
                                      mask, QueryTriggerInteraction.Ignore))
                {
                    missing++;
                }
            }

            return (float)missing / 4f;
        }

        /// <summary>
        /// Обчислює близькість точки до Danger-зони (0 = далеко, 1 = в зоні).
        /// </summary>
        private static float ComputeDangerProximity(Vector3 point)
        {
            Collider[] colliders = Physics.OverlapSphere(point, DangerSearchRadius);

            float closestDist = DangerSearchRadius;

            foreach (Collider col in colliders)
            {
                if (col.isTrigger && col.CompareTag("Danger"))
                {
                    float dist = Vector3.Distance(point, col.ClosestPoint(point));
                    if (dist < closestDist)
                        closestDist = dist;
                }
            }

            // Інверсія: 0 = далеко (на відстані DangerSearchRadius), 1 = в зоні
            return 1f - (closestDist / DangerSearchRadius);
        }

        /// <summary>
        /// Обчислює "чисту" довжину маршруту (без штрафів безпеки).
        /// </summary>
        public static float PathLength(List<Vector3> path)
        {
            if (path == null || path.Count < 2) return 0f;
            float len = 0f;
            for (int i = 1; i < path.Count; i++)
                len += Vector3.Distance(path[i - 1], path[i]);
            return len;
        }
    }
}
