using System.Collections.Generic;
using UnityEngine;

namespace Navigation.Comparison
{
    /// <summary>
    /// Агент, що рухається по маршруту RRT*.
    /// Простіший за NPCController — без стрибків і складних станів,
    /// бо RRT* не надає інформацію про балістику.
    /// Просто йде від точки до точки по прямій.
    /// </summary>
    [RequireComponent(typeof(Rigidbody))]
    public class RRTAgent : MonoBehaviour
    {
        [Header("Посилання")]
        [SerializeField] private RRTStarBenchmark rrtBenchmark;

        [Header("Рух")]
        [SerializeField] private float moveSpeed = 5f;
        [SerializeField] private float waypointReachDist = 0.8f;
        [SerializeField] private float rotationSpeed = 360f;

        [Header("Стан (read-only)")]
        [SerializeField] private bool isMoving;
        [SerializeField] private int currentWaypoint;
        [SerializeField] private bool isFinished;

        private Rigidbody rb;
        private List<Vector3> path;

        public bool IsFinished => isFinished;
        public bool IsDead { get; private set; }

        private void Awake()
        {
            rb = GetComponent<Rigidbody>();
            rb.freezeRotation = true;
            rb.interpolation = RigidbodyInterpolation.Interpolate;
        }

        private void Start()
        {
            Invoke(nameof(TryGetPath), 1f);
        }

        private void TryGetPath()
        {
            if (isMoving || rrtBenchmark == null) return;

            rrtBenchmark.FindPath();

            if (rrtBenchmark.LastPathFound())
            {
                path = rrtBenchmark.GetLastPath();
                if (path != null && path.Count >= 2)
                {
                    currentWaypoint = 1;
                    isMoving = true;
                    isFinished = false;
                    Debug.Log($"[RRT*Agent] Маршрут отримано: {path.Count} точок");
                }
                else
                {
                    Debug.LogWarning("[RRT*Agent] Маршрут порожній.");
                }
            }
            else
            {
                Debug.LogWarning("[RRT*Agent] Шлях не знайдено.");
            }
        }

        private void FixedUpdate()
        {
            if (!isMoving || path == null || IsDead) return;

            if (currentWaypoint >= path.Count)
            {
                isFinished = true;
                isMoving = false;
                rb.linearVelocity = Vector3.zero;
                Debug.Log("[RRT*Agent] Маршрут завершено!");
                return;
            }

            Vector3 target = path[currentWaypoint];
            Vector3 dir = target - transform.position;
            dir.y = 0;
            float dist = dir.magnitude;

            if (dist < waypointReachDist)
            {
                currentWaypoint++;
                return;
            }

            // Поворот
            if (dir.sqrMagnitude > 0.01f)
            {
                Quaternion targetRot = Quaternion.LookRotation(dir.normalized);
                transform.rotation = Quaternion.RotateTowards(
                    transform.rotation, targetRot, rotationSpeed * Time.fixedDeltaTime);
            }

            // Рух
            Vector3 vel = dir.normalized * moveSpeed;
            vel.y = rb.linearVelocity.y;
            rb.linearVelocity = vel;
        }

        public void Stop()
        {
            isMoving = false;
            rb.linearVelocity = Vector3.zero;
        }

        // Смерть від Danger / падіння
        private void OnTriggerEnter(Collider other)
        {
            if (other.CompareTag("Danger"))
            {
                IsDead = true;
                Stop();
                Debug.LogWarning("[RRT*Agent] Загинув у Danger-зоні!");
            }
        }

        private void Update()
        {
            if (transform.position.y < -50f && !IsDead)
            {
                IsDead = true;
                Stop();
                Debug.LogWarning("[RRT*Agent] Загинув — впав у прірву!");
            }
        }
    }
}