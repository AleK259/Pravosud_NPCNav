using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;
using Debug = UnityEngine.Debug;

namespace Navigation.Comparison
{
    /// <summary>
    /// RRT* з підтримкою стрибків для коректного порівняння.
    /// 
    /// Розширення класичного RRT*:
    /// 1. Вузли проєктуються на поверхню (Raycast вниз)
    /// 2. Walk-з'єднання: SphereCast по горизонталі + перевірка прірв
    /// 3. Jump-з'єднання: якщо walk неможливий (прірва/перепад висоти),
    ///    пробуємо балістичну траєкторію (як у основній системі)
    /// 
    /// Це дає RRT* можливість долати прірви — більш справедливе
    /// порівняння з SVO+A*, який теж використовує стрибки.
    /// </summary>
    public class RRTStarPathfinder
    {
        public class RRTNode
        {
            public Vector3 Position;
            public RRTNode Parent;
            public float CostFromStart;
            public bool IsJumpEdge; // Чи прийшли сюди стрибком
            public List<RRTNode> Children = new List<RRTNode>();
        }

        // --- Параметри ---
        public int MaxIterations { get; set; } = 5000;
        public float StepSize { get; set; } = 1.5f;
        public float GoalRadius { get; set; } = 1.5f;
        public float RewireRadius { get; set; } = 3.0f;
        public float GoalBias { get; set; } = 0.15f;
        public float AgentRadius { get; set; } = 0.3f;
        public float AgentHeight { get; set; } = 1.8f;
        public float MaxJumpSpeed { get; set; } = 10f;
        public float MaxJumpVerticalSpeed { get; set; } = 8f;
        public float Gravity { get; set; } = 9.81f;
        public LayerMask ObstacleMask { get; set; } = ~0;
        public float SearchPadding { get; set; } = 5f;

        // --- Обчислювані ---
        private float MaxJumpHeight => (MaxJumpVerticalSpeed * MaxJumpVerticalSpeed) / (2f * Gravity);
        private float MaxJumpDistance => (MaxJumpSpeed * MaxJumpSpeed) / Gravity;

        // --- Результати ---
        public List<RRTNode> AllNodes { get; private set; }
        public List<Vector3> LastPath { get; private set; }
        public float LastSearchTimeMs { get; private set; }
        public int LastIterations { get; private set; }
        public bool LastSuccess { get; private set; }
        public int LastJumpCount { get; private set; }

        public List<Vector3> FindPath(Vector3 start, Vector3 goal)
        {
            Stopwatch sw = Stopwatch.StartNew();
            AllNodes = new List<RRTNode>();
            LastPath = null;
            LastSuccess = false;
            LastJumpCount = 0;

            Vector3 projStart = ProjectToSurface(start);
            Vector3 projGoal = ProjectToSurface(goal);

            if (projStart == Vector3.zero || projGoal == Vector3.zero)
            {
                sw.Stop();
                LastSearchTimeMs = (float)sw.Elapsed.TotalMilliseconds;
                return null;
            }

            RRTNode root = new RRTNode
            {
                Position = projStart,
                Parent = null,
                CostFromStart = 0f,
                IsJumpEdge = false
            };
            AllNodes.Add(root);

            Vector3 boundsMin = Vector3.Min(projStart, projGoal) - Vector3.one * SearchPadding;
            Vector3 boundsMax = Vector3.Max(projStart, projGoal) + Vector3.one * SearchPadding;

            RRTNode goalNode = null;

            for (int i = 0; i < MaxIterations; i++)
            {
                // 1. Випадкова точка
                Vector3 randomPoint;
                if (Random.value < GoalBias)
                {
                    randomPoint = projGoal;
                }
                else
                {
                    randomPoint = new Vector3(
                        Random.Range(boundsMin.x, boundsMax.x),
                        Random.Range(boundsMin.y, boundsMax.y),
                        Random.Range(boundsMin.z, boundsMax.z)
                    );
                    Vector3 proj = ProjectToSurface(randomPoint);
                    if (proj == Vector3.zero) continue;
                    randomPoint = proj;
                }

                // 2. Найближчий вузол
                RRTNode nearest = FindNearest(randomPoint);

                // 3. Крок — зберігаємо Y-компоненту для вертикального дослідження.
                // Якщо обнулити Y, дерево розширюється тільки горизонтально
                // і ніколи не знаходить поверхні на інших висотах.
                Vector3 direction = randomPoint - nearest.Position;
                float dist = direction.magnitude;
                if (dist < 0.1f) continue;
                if (dist > StepSize) direction = direction.normalized * StepSize;

                Vector3 newPos = nearest.Position + direction;
                Vector3 projected = ProjectToSurface(newPos);
                if (projected == Vector3.zero) continue;
                newPos = projected;

                // 4. Спробуємо з'єднати: walk або jump
                bool canWalk = IsWalkable(nearest.Position, newPos);
                bool isJump = false;

                if (!canWalk)
                {
                    // Пробуємо стрибок
                    if (CanJump(nearest.Position, newPos))
                    {
                        isJump = true;
                    }
                    else
                    {
                        continue; // Ні walk, ні jump — пропускаємо
                    }
                }

                // 5. Вартість
                float edgeCost = Vector3.Distance(nearest.Position, newPos);
                if (isJump) edgeCost *= 2.5f; // Стрибок дорожчий
                float newCost = nearest.CostFromStart + edgeCost;

                RRTNode newNode = new RRTNode
                {
                    Position = newPos,
                    Parent = nearest,
                    CostFromStart = newCost,
                    IsJumpEdge = isJump
                };

                // 6. Rewire (тільки для walk-з'єднань)
                List<RRTNode> nearbyNodes = FindNearby(newPos, RewireRadius);
                foreach (RRTNode candidate in nearbyNodes)
                {
                    if (IsWalkable(candidate.Position, newPos))
                    {
                        float candidateCost = candidate.CostFromStart +
                                               Vector3.Distance(candidate.Position, newPos);
                        if (candidateCost < newNode.CostFromStart)
                        {
                            newNode.Parent = candidate;
                            newNode.CostFromStart = candidateCost;
                            newNode.IsJumpEdge = false;
                        }
                    }
                }

                newNode.Parent.Children.Add(newNode);
                AllNodes.Add(newNode);

                // Rewire сусідів
                foreach (RRTNode neighbor in nearbyNodes)
                {
                    if (neighbor == newNode) continue;
                    if (!IsWalkable(newNode.Position, neighbor.Position)) continue;

                    float throughNew = newNode.CostFromStart +
                                        Vector3.Distance(newNode.Position, neighbor.Position);
                    if (throughNew < neighbor.CostFromStart)
                    {
                        neighbor.Parent?.Children.Remove(neighbor);
                        neighbor.Parent = newNode;
                        neighbor.CostFromStart = throughNew;
                        neighbor.IsJumpEdge = false;
                        newNode.Children.Add(neighbor);
                    }
                }

                // 7. Ціль
                if (Vector3.Distance(newPos, projGoal) <= GoalRadius)
                {
                    goalNode = newNode;
                    break;
                }
            }

            sw.Stop();
            LastSearchTimeMs = (float)sw.Elapsed.TotalMilliseconds;
            LastIterations = AllNodes.Count;

            if (goalNode != null)
            {
                LastPath = ReconstructPath(goalNode);
                LastSuccess = true;
                CountJumps(goalNode);
            }

            return LastPath;
        }

        // =====================================================================
        //  СТРИБОК (спрощена балістика)
        // =====================================================================

        /// <summary>
        /// Перевіряє чи можна стрибнути між двома точками.
        /// Спрощена версія: пробує 3 варіанти часу, перевіряє траєкторію.
        /// </summary>
        private bool CanJump(Vector3 from, Vector3 to)
        {
            float hDist = new Vector2(to.x - from.x, to.z - from.z).magnitude;
            float vDist = to.y - from.y;

            if (hDist > MaxJumpDistance) return false;
            if (vDist > MaxJumpHeight) return false;

            float halfHeight = AgentHeight * 0.5f;
            Vector3 jumpFrom = from + Vector3.up * halfHeight;
            Vector3 jumpTo = to + Vector3.up * halfHeight;
            Vector3 delta = jumpTo - jumpFrom;
            Vector3 grav = new Vector3(0, -Gravity, 0);

            float estimated = hDist / (MaxJumpSpeed * 0.5f);
            if (estimated < 0.3f) estimated = 0.3f;

            float[] times = { estimated * 1.5f, estimated, estimated * 0.8f };

            foreach (float t in times)
            {
                if (t < 0.15f || t > 3f) continue;

                Vector3 v0 = (delta - 0.5f * grav * t * t) / t;
                if (v0.magnitude > MaxJumpSpeed) continue;
                if (v0.y > MaxJumpVerticalSpeed || v0.y < -1f) continue;

                // Перевірка траєкторії (5 точок)
                bool clear = true;
                for (int i = 1; i <= 5; i++)
                {
                    float frac = i / 6f;
                    float ti = frac * t;
                    Vector3 point = jumpFrom + v0 * ti + 0.5f * grav * ti * ti;

                    if (Physics.CheckSphere(point, AgentRadius,
                                             ObstacleMask, QueryTriggerInteraction.Ignore))
                    {
                        clear = false;
                        break;
                    }
                }

                if (clear) return true;
            }

            return false;
        }

        // =====================================================================
        //  WALK
        // =====================================================================

        private bool IsWalkable(Vector3 from, Vector3 to)
        {
            if (Mathf.Abs(from.y - to.y) > 0.8f) return false;

            Vector3 dir = to - from;
            dir.y = 0;
            float dist = dir.magnitude;
            if (dist < 0.01f) return true;

            Vector3 castFrom = from + Vector3.up * (AgentHeight * 0.5f);
            if (Physics.SphereCast(castFrom, AgentRadius * 0.9f, dir.normalized,
                                    out RaycastHit _, dist,
                                    ObstacleMask, QueryTriggerInteraction.Ignore))
                return false;

            int checks = Mathf.Max(2, Mathf.CeilToInt(dist / 0.5f));
            for (int i = 1; i < checks; i++)
            {
                float t = (float)i / checks;
                Vector3 checkPos = Vector3.Lerp(from, to, t) + Vector3.up * 1f;
                if (!Physics.Raycast(checkPos, Vector3.down, 3f,
                                      ObstacleMask, QueryTriggerInteraction.Ignore))
                    return false;
            }

            return true;
        }

        // =====================================================================
        //  ДОПОМІЖНІ
        // =====================================================================

        private Vector3 ProjectToSurface(Vector3 point)
        {
            // Кастуємо з НЕВЕЛИКОЮ висотою над точкою (1.5м, не 10м).
            // Це знаходить поверхню БЛИЗЬКО до Y-координати точки,
            // а не найвищу поверхню в стовпці (стелю верхнього поверху).
            // На багатоповерховій сцені це дозволяє знаходити поверхні
            // на різних висотах.
            Vector3 rayOrigin = point + Vector3.up * 1.5f;

            if (Physics.Raycast(rayOrigin, Vector3.down, out RaycastHit hit, 4f,
                                 ObstacleMask, QueryTriggerInteraction.Ignore))
            {
                if (Vector3.Angle(hit.normal, Vector3.up) <= 45f)
                {
                    // Перевіряємо clearance — чи влізе агент
                    Vector3 surfPoint = hit.point + Vector3.up * 0.1f;
                    Vector3 capsBot = surfPoint + Vector3.up * AgentRadius;
                    Vector3 capsTop = surfPoint + Vector3.up * (AgentHeight - AgentRadius);

                    if (!Physics.CheckCapsule(capsBot, capsTop, AgentRadius * 0.8f,
                                               ObstacleMask, QueryTriggerInteraction.Ignore))
                    {
                        return surfPoint;
                    }
                }
            }

            return Vector3.zero;
        }

        private RRTNode FindNearest(Vector3 point)
        {
            RRTNode nearest = AllNodes[0];
            float minDist = float.MaxValue;
            foreach (RRTNode node in AllNodes)
            {
                float d = Vector3.Distance(node.Position, point);
                if (d < minDist) { minDist = d; nearest = node; }
            }
            return nearest;
        }

        private List<RRTNode> FindNearby(Vector3 point, float radius)
        {
            List<RRTNode> result = new List<RRTNode>();
            float rSqr = radius * radius;
            foreach (RRTNode node in AllNodes)
                if ((node.Position - point).sqrMagnitude <= rSqr)
                    result.Add(node);
            return result;
        }

        private List<Vector3> ReconstructPath(RRTNode goal)
        {
            List<Vector3> path = new List<Vector3>();
            RRTNode c = goal;
            while (c != null) { path.Add(c.Position); c = c.Parent; }
            path.Reverse();
            return path;
        }

        private void CountJumps(RRTNode goal)
        {
            LastJumpCount = 0;
            RRTNode c = goal;
            while (c != null)
            {
                if (c.IsJumpEdge) LastJumpCount++;
                c = c.Parent;
            }
        }

        public float GetPathLength()
        {
            if (LastPath == null || LastPath.Count < 2) return 0f;
            float len = 0f;
            for (int i = 1; i < LastPath.Count; i++)
                len += Vector3.Distance(LastPath[i - 1], LastPath[i]);
            return len;
        }
    }
}