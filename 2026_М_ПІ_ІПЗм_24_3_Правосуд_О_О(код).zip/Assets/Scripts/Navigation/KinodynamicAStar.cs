using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;
using Navigation.Voxelization;
using Debug = UnityEngine.Debug;

namespace Navigation
{
    /// <summary>
    /// Модифікований алгоритм A* для кінодинамічного планування (розділ 4.4 роботи).
    /// 
    /// Відмінності від класичного A*:
    /// 1. Комбінована евристика h(n) з формули 4.2 — враховує горизонтальну
    ///    відстань, вертикальну різницю (з ваговим коефіцієнтом) та небезпеку зони.
    /// 2. Сусіди генеруються динамічно через NavGraph.GetNeighbors(),
    ///    який перевіряє фізичну допустимість переходів (балістика стрибків).
    /// 3. Вартість ребер асиметрична: стрибок вгору дорожчий за падіння вниз.
    /// 
    /// Оптимізації:
    /// - Ліміт ітерацій (щоб не блокувати ігровий цикл, розділ 3.4).
    /// - Пріоритетна черга на основі SortedSet для O(log n) вставки/видалення.
    /// </summary>
    public class KinodynamicAStar
    {
        private readonly NavGraph navGraph;

        // --- Параметри евристики (формула 4.2) ---

        /// <summary>
        /// Ваговий коефіцієнт вертикальної різниці (wy з формули 4.2).
        /// Відображає складність набору висоти: значення > 1 означає,
        /// що рухатися вгору складніше, ніж по горизонталі.
        /// </summary>
        public float HeightWeight { get; set; } = 2.0f;

        /// <summary>
        /// Ваговий коефіцієнт небезпеки зони (w_danger з формули 4.2).
        /// Високе значення змусить агента обходити небезпечні зони.
        /// </summary>
        public float DangerWeight { get; set; } = 5.0f;

        /// <summary>
        /// Коефіцієнт підсилення евристики (epsilon).
        /// Значення > 1 прискорює пошук, але може дати неоптимальний шлях.
        /// 1.0 = оптимальний A*, 1.5 = Weighted A* (швидше, але довший шлях).
        /// </summary>
        public float HeuristicWeight { get; set; } = 1.2f;

        // --- Ліміти продуктивності ---

        /// <summary>
        /// Максимальна кількість ітерацій (розкритих вузлів).
        /// Захист від зависання на великих сценах.
        /// </summary>
        public int MaxIterations { get; set; } = 5000;

        /// <summary>
        /// Максимальний час пошуку (мілісекунди).
        /// Відповідає вимозі 5-10 мс з розділу 3.4 роботи.
        /// </summary>
        public float MaxSearchTimeMs { get; set; } = 200f;

        // =====================================================================
        //  ВНУТРІШНІ СТРУКТУРИ
        // =====================================================================

        /// <summary>
        /// Внутрішній вузол пошуку — зберігає A*-дані для кожного вокселя.
        /// </summary>
        private class SearchNode
        {
            public VoxelNode Voxel;       // Відповідний воксель октодерева
            public SearchNode Parent;     // Батьківський вузол (для відновлення шляху)
            public NavEdge? EdgeFromParent; // Ребро, яким прийшли від батька
            public float G;               // Вартість шляху від старту
            public float H;               // Евристична оцінка до цілі
            public float F => G + H;      // Повна вартість f(n) = g(n) + h(n)
        }

        /// <summary>
        /// Компаратор для пріоритетної черги: сортує за F, потім за H.
        /// </summary>
        private class SearchNodeComparer : IComparer<SearchNode>
        {
            public int Compare(SearchNode a, SearchNode b)
            {
                int fCompare = a.F.CompareTo(b.F);
                if (fCompare != 0) return fCompare;

                // При рівних F — пріоритет вузлу з меншим H (ближчому до цілі)
                int hCompare = a.H.CompareTo(b.H);
                if (hCompare != 0) return hCompare;

                // Для унікальності в SortedSet (не дозволяє дублікати)
                return a.GetHashCode().CompareTo(b.GetHashCode());
            }
        }

        // =====================================================================
        //  КОНСТРУКТОР
        // =====================================================================

        public KinodynamicAStar(NavGraph navGraph)
        {
            this.navGraph = navGraph;
        }

        // =====================================================================
        //  ОСНОВНИЙ МЕТОД ПОШУКУ
        // =====================================================================

        /// <summary>
        /// Знаходить шлях між двома позиціями у світових координатах.
        /// 
        /// Алгоритм:
        /// 1. Знаходить найближчі Ground-вокселі до start та goal.
        /// 2. Ініціалізує Open List (пріоритетна черга) та Closed List (HashSet).
        /// 3. На кожній ітерації:
        ///    a) Витягує вузол з мінімальним f(n) з Open List.
        ///    b) Якщо це ціль — відновлює шлях і повертає результат.
        ///    c) Генерує сусідів через NavGraph.GetNeighbors().
        ///    d) Для кожного сусіда обчислює g(n') і h(n'), додає в Open List.
        /// 4. Якщо Open List порожній або ліміт перевищено — повертає неуспіх.
        /// </summary>
        /// <param name="startPos">Стартова позиція у світі</param>
        /// <param name="goalPos">Цільова позиція у світі</param>
        /// <returns>Результат пошуку з маршрутом або статусом помилки</returns>
        public PathResult FindPath(Vector3 startPos, Vector3 goalPos)
        {
            Stopwatch sw = Stopwatch.StartNew();
            PathResult result = new PathResult();

            // --- Знаходимо стартовий та цільовий вокселі ---
            VoxelNode startVoxel = navGraph.FindNearestGroundVoxel(startPos, 5f);
            VoxelNode goalVoxel = navGraph.FindNearestGroundVoxel(goalPos, 5f);

            if (startVoxel == null)
            {
                result.Status = PathStatus.InvalidStart;
                result.SearchTimeMs = (float)sw.Elapsed.TotalMilliseconds;
                Debug.LogWarning("[A*] Стартова позиція не знаходиться на Ground-вокселі.");
                return result;
            }

            if (goalVoxel == null)
            {
                result.Status = PathStatus.InvalidGoal;
                result.SearchTimeMs = (float)sw.Elapsed.TotalMilliseconds;
                Debug.LogWarning("[A*] Цільова позиція не знаходиться на Ground-вокселі.");
                return result;
            }

            // --- Ініціалізація ---
            // Open List — пріоритетна черга (SortedSet з кастомним компаратором)
            SortedSet<SearchNode> openSet = new SortedSet<SearchNode>(new SearchNodeComparer());

            // Closed List — множина вже оброблених вокселів
            HashSet<VoxelNode> closedSet = new HashSet<VoxelNode>();

            // Словник для швидкого доступу до SearchNode за VoxelNode
            Dictionary<VoxelNode, SearchNode> nodeMap = new Dictionary<VoxelNode, SearchNode>();

            // Стартовий вузол
            SearchNode startNode = new SearchNode
            {
                Voxel = startVoxel,
                Parent = null,
                EdgeFromParent = null,
                G = 0f,
                H = CalculateHeuristic(startVoxel, goalVoxel)
            };

            openSet.Add(startNode);
            nodeMap[startVoxel] = startNode;

            int iterations = 0;
            int maxOpenSize = 1;

            // =====================================================================
            //  ГОЛОВНИЙ ЦИКЛ A*
            // =====================================================================

            while (openSet.Count > 0)
            {
                // --- Перевірка лімітів ---
                iterations++;
                if (iterations > MaxIterations)
                {
                    result.Status = PathStatus.Timeout;
                    result.IterationCount = iterations;
                    result.SearchTimeMs = (float)sw.Elapsed.TotalMilliseconds;
                    result.MaxOpenListSize = maxOpenSize;
                    Debug.LogWarning($"[A*] Перевищено ліміт ітерацій ({MaxIterations}).");
                    return result;
                }

                if (sw.Elapsed.TotalMilliseconds > MaxSearchTimeMs)
                {
                    result.Status = PathStatus.Timeout;
                    result.IterationCount = iterations;
                    result.SearchTimeMs = (float)sw.Elapsed.TotalMilliseconds;
                    result.MaxOpenListSize = maxOpenSize;
                    Debug.LogWarning($"[A*] Перевищено ліміт часу ({MaxSearchTimeMs} мс).");
                    return result;
                }

                // --- Витягуємо вузол з мінімальним f(n) ---
                SearchNode current = openSet.Min;
                openSet.Remove(current);

                // --- Перевірка цілі ---
                if (current.Voxel == goalVoxel)
                {
                    // Шлях знайдено — відновлюємо маршрут
                    result.Status = PathStatus.Found;
                    result.Steps = ReconstructPath(current);
                    result.TotalCost = current.G;
                    result.IterationCount = iterations;
                    result.SearchTimeMs = (float)sw.Elapsed.TotalMilliseconds;
                    result.MaxOpenListSize = maxOpenSize;

                    Debug.Log($"[A*] Шлях знайдено! {result}");
                    return result;
                }

                // --- Додаємо до Closed List ---
                closedSet.Add(current.Voxel);

                // --- Розкриваємо сусідів ---
                List<NavEdge> neighbors = navGraph.GetNeighbors(current.Voxel);

                foreach (NavEdge edge in neighbors)
                {
                    VoxelNode neighborVoxel = edge.To;

                    // Пропускаємо вже оброблені вузли
                    if (closedSet.Contains(neighborVoxel)) continue;

                    // Обчислюємо нову вартість g(n')
                    float tentativeG = current.G + edge.Cost;

                    // Перевіряємо, чи вже є цей вузол в Open List
                    if (nodeMap.TryGetValue(neighborVoxel, out SearchNode existingNode))
                    {
                        // Вузол вже в Open List — перевіряємо, чи новий шлях кращий
                        if (tentativeG < existingNode.G)
                        {
                            // Видаляємо старий запис з SortedSet
                            openSet.Remove(existingNode);

                            // Оновлюємо дані
                            existingNode.G = tentativeG;
                            existingNode.Parent = current;
                            existingNode.EdgeFromParent = edge;

                            // Додаємо оновлений запис назад
                            openSet.Add(existingNode);
                        }
                    }
                    else
                    {
                        // Новий вузол — створюємо та додаємо
                        SearchNode newNode = new SearchNode
                        {
                            Voxel = neighborVoxel,
                            Parent = current,
                            EdgeFromParent = edge,
                            G = tentativeG,
                            H = CalculateHeuristic(neighborVoxel, goalVoxel) * HeuristicWeight
                        };

                        openSet.Add(newNode);
                        nodeMap[neighborVoxel] = newNode;
                    }
                }

                // Оновлюємо статистику
                if (openSet.Count > maxOpenSize)
                    maxOpenSize = openSet.Count;
            }

            // --- Open List порожній — шлях не існує ---
            result.Status = PathStatus.NotFound;
            result.IterationCount = iterations;
            result.SearchTimeMs = (float)sw.Elapsed.TotalMilliseconds;
            result.MaxOpenListSize = maxOpenSize;
            Debug.LogWarning("[A*] Шлях не знайдено. Ціль недосяжна.");
            return result;
        }

        // =====================================================================
        //  ЕВРИСТИЧНА ФУНКЦІЯ (формула 4.2 з роботи)
        // =====================================================================

        /// <summary>
        /// Комбінована евристика для кінодинамічного планування.
        /// 
        /// h(n) = √((xg-xn)² + (zg-zn)²) + wy·|yg-yn| + w_danger·Danger(n)
        /// 
        /// Компоненти:
        /// 1. Горизонтальна евклідова відстань — базова оцінка.
        /// 2. Вертикальна різниця з вагою — штраф за набір висоти
        ///    (бо стрибок вгору складніший за рух по горизонталі).
        /// 3. Потенціал небезпеки — штраф за наближення до Danger-зон.
        /// </summary>
        private float CalculateHeuristic(VoxelNode from, VoxelNode goal)
        {
            Vector3 delta = goal.Center - from.Center;

            // Горизонтальна відстань
            float horizontalDist = Mathf.Sqrt(delta.x * delta.x + delta.z * delta.z);

            // Вертикальна різниця з вагою
            float verticalCost = HeightWeight * Mathf.Abs(delta.y);

            // Потенціал небезпеки поточного вокселя
            float dangerCost = DangerWeight * from.DangerLevel;

            return horizontalDist + verticalCost + dangerCost;
        }

        // =====================================================================
        //  ВІДНОВЛЕННЯ МАРШРУТУ
        // =====================================================================

        /// <summary>
        /// Відновлює послідовність кроків від старту до цілі,
        /// рухаючись від цільового вузла до стартового через Parent-посилання.
        /// </summary>
        private List<PathStep> ReconstructPath(SearchNode goalNode)
        {
            List<PathStep> path = new List<PathStep>();

            SearchNode current = goalNode;
            while (current != null)
            {
                PathStep step = new PathStep
                {
                    Position = current.Voxel.Center,
                    Node = current.Voxel,
                    TransitionType = EdgeType.Walk, // За замовчуванням
                    LaunchVelocity = Vector3.zero,
                    FlightTime = 0f,
                    StepCost = 0f
                };

                // Якщо є ребро від батька — заповнюємо деталі переходу
                if (current.EdgeFromParent.HasValue)
                {
                    NavEdge edge = current.EdgeFromParent.Value;
                    step.TransitionType = edge.Type;
                    step.LaunchVelocity = edge.LaunchVelocity;
                    step.FlightTime = edge.FlightTime;
                    step.StepCost = edge.Cost;
                }

                path.Add(step);
                current = current.Parent;
            }

            // Розвертаємо: від старту до цілі
            path.Reverse();
            return path;
        }
    }
}