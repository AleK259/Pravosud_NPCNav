using System.Collections.Generic;
using UnityEngine;
using Navigation.Voxelization;

namespace Navigation
{
    /// <summary>
    /// Просторовий хеш для швидкого пошуку сусідніх вокселів.
    /// 
    /// Замість перебору всіх N вокселів (O(N) на кожен запит),
    /// ділить простір на комірки і шукає тільки у сусідніх комірках (O(1) в середньому).
    /// 
    /// Це критична оптимізація для A*: без неї кожна ітерація
    /// перебирає 468+ вокселів, а з нею — лише 5-20.
    /// </summary>
    public class SpatialHashGrid
    {
        private readonly Dictionary<long, List<VoxelNode>> cells;
        private readonly float cellSize;

        /// <summary>
        /// Створює просторовий хеш.
        /// </summary>
        /// <param name="cellSize">Розмір комірки (метри). 
        /// Зазвичай = максимальна дальність стрибка агента.</param>
        public SpatialHashGrid(float cellSize)
        {
            this.cellSize = cellSize;
            this.cells = new Dictionary<long, List<VoxelNode>>();
        }

        /// <summary>
        /// Додає всі Ground-вокселі у хеш-таблицю.
        /// Викликається один раз після побудови октодерева.
        /// </summary>
        public void Build(IEnumerable<VoxelNode> groundVoxels)
        {
            cells.Clear();

            foreach (VoxelNode voxel in groundVoxels)
            {
                long key = GetCellKey(voxel.Center);

                if (!cells.TryGetValue(key, out List<VoxelNode> list))
                {
                    list = new List<VoxelNode>(8);
                    cells[key] = list;
                }

                list.Add(voxel);
            }
        }

        /// <summary>
        /// Повертає всі вокселі в межах заданого радіусу від позиції.
        /// Перевіряє лише сусідні комірки хешу — O(1) замість O(N).
        /// </summary>
        /// <param name="position">Центр пошуку</param>
        /// <param name="radius">Радіус пошуку (метри)</param>
        /// <returns>Список вокселів у радіусі</returns>
        public List<VoxelNode> GetNearby(Vector3 position, float radius)
        {
            List<VoxelNode> result = new List<VoxelNode>(32);

            // Визначаємо діапазон комірок, які потрібно перевірити
            int minCX = Mathf.FloorToInt((position.x - radius) / cellSize);
            int maxCX = Mathf.FloorToInt((position.x + radius) / cellSize);
            int minCY = Mathf.FloorToInt((position.y - radius) / cellSize);
            int maxCY = Mathf.FloorToInt((position.y + radius) / cellSize);
            int minCZ = Mathf.FloorToInt((position.z - radius) / cellSize);
            int maxCZ = Mathf.FloorToInt((position.z + radius) / cellSize);

            float radiusSqr = radius * radius;

            for (int cx = minCX; cx <= maxCX; cx++)
            {
                for (int cy = minCY; cy <= maxCY; cy++)
                {
                    for (int cz = minCZ; cz <= maxCZ; cz++)
                    {
                        long key = PackKey(cx, cy, cz);

                        if (cells.TryGetValue(key, out List<VoxelNode> cellList))
                        {
                            foreach (VoxelNode voxel in cellList)
                            {
                                // Фінальна перевірка відстані
                                float distSqr = (voxel.Center - position).sqrMagnitude;
                                if (distSqr <= radiusSqr)
                                {
                                    result.Add(voxel);
                                }
                            }
                        }
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Обчислює ключ комірки для заданої позиції.
        /// </summary>
        private long GetCellKey(Vector3 position)
        {
            int cx = Mathf.FloorToInt(position.x / cellSize);
            int cy = Mathf.FloorToInt(position.y / cellSize);
            int cz = Mathf.FloorToInt(position.z / cellSize);
            return PackKey(cx, cy, cz);
        }

        /// <summary>
        /// Пакує три цілих числа в один long для використання як ключ Dictionary.
        /// </summary>
        private long PackKey(int x, int y, int z)
        {
            // Зсуваємо координати у додатній діапазон і пакуємо в 64 біти
            // Кожна координата займає ~20 біт (діапазон ±500000)
            long lx = (long)(x + 500000);
            long ly = (long)(y + 500000);
            long lz = (long)(z + 500000);
            return (lx * 1000000L + ly) * 1000000L + lz;
        }
    }
}
