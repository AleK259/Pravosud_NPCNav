using System.Collections.Generic;
using UnityEngine;
using Navigation.Agent;
using Navigation.Voxelization;

namespace Navigation
{
    /// <summary>
    /// Головний менеджер навігаційної системи.
    /// Зв'язує всі компоненти: октодерево, навігаційний граф,
    /// фізику стрибків та алгоритм A*.
    /// 
    /// Прикріплюється до GameObject у сцені.
    /// Візуалізує знайдений шлях через Gizmos:
    /// - Білі лінії для пішохідних переходів
    /// - Жовті параболи для стрибків
    /// - Помаранчеві лінії для падінь
    /// </summary>
    public class NavigationManager : MonoBehaviour
    {
        // =====================================================================
        //  ЗАЛЕЖНОСТІ (налаштовуються в Inspector)
        // =====================================================================

        [Header("Компоненти")]
        [Tooltip("Посилання на SceneVoxelizer у сцені.")]
        [SerializeField] private SceneVoxelizer sceneVoxelizer;

        [Tooltip("Профіль агента (ScriptableObject з фізичними параметрами).")]
        [SerializeField] private AgentParameters agentParameters;

        [Header("Стартова та цільова точки")]
        [Tooltip("Transform стартової позиції (SpawnPoint).")]
        [SerializeField] private Transform startPoint;

        [Tooltip("Transform цільової позиції (GoalPoint).")]
        [SerializeField] private Transform goalPoint;

        [Header("Параметри A*")]
        [Tooltip("Ваговий коефіцієнт висоти (wy з формули 4.2). " +
                 "Більше = агент уникатиме набору висоти.")]
        [Range(0.5f, 5f)]
        [SerializeField] private float heightWeight = 2.0f;

        [Tooltip("Ваговий коефіцієнт небезпеки (w_danger з формули 4.2).")]
        [Range(0f, 20f)]
        [SerializeField] private float dangerWeight = 5.0f;

        [Tooltip("Підсилення евристики. 1.0 = оптимальний, >1 = швидше але довший шлях.")]
        [Range(1.0f, 3.0f)]
        [SerializeField] private float heuristicWeight = 1.2f;

        [Tooltip("Максимум ітерацій A*.")]
        [SerializeField] private int maxIterations = 5000;

        [Tooltip("Максимальний час пошуку (мс).")]
        [SerializeField] private float maxSearchTimeMs = 200f;

        [Header("Параметри графа")]
        [Tooltip("Максимальна висота безпечного падіння (метри).")]
        [SerializeField] private float maxSafeFallHeight = 5f;

        [Tooltip("Страх падіння: множник вартості walk-ребер біля краю платформи. " +
                 "0 = вимкнено, 2 = помірний, 5 = сильний. " +
                 "Змушує агента обирати шлях ближче до центру платформи.")]
        [Range(0f, 5f)]
        [SerializeField] private float fallFearMultiplier = 2.0f;

        [Header("Шари перешкод")]
        [Tooltip("Шари для перевірки колізій при стрибках.")]
        [SerializeField] private LayerMask obstacleLayers = ~0;

        [Header("Візуалізація")]
        [SerializeField] private bool showPath = true;
        [SerializeField] private bool showJumpArcs = true;
        [SerializeField] private bool showNodeLabels = false;

        [Tooltip("Показувати тепловізійну карту 'страху падіння'. " +
                 "Зелений = безпечний центр, Червоний = небезпечний край.")]
        [SerializeField] private bool showFallFearHeatmap = false;

        [Tooltip("Прозорість тепловізійної карти.")]
        [Range(0.1f, 1f)]
        [SerializeField] private float heatmapAlpha = 0.6f;

        [Header("Кольори")]
        [SerializeField] private Color walkColor = Color.white;
        [SerializeField] private Color jumpColor = Color.yellow;
        [SerializeField] private Color fallColor = new Color(1f, 0.5f, 0f); // Помаранчевий
        [SerializeField] private Color startColor = Color.green;
        [SerializeField] private Color goalColor = Color.cyan;

        [Header("Автозапуск")]
        [Tooltip("Автоматично шукати шлях після побудови октодерева.")]
        [SerializeField] private bool autoFindPath = true;

        [Tooltip("Затримка перед пошуком шляху (секунди).")]
        [SerializeField] private float findPathDelay = 0.3f;

        // =====================================================================
        //  ВНУТРІШНІ ДАНІ
        // =====================================================================

        private NavGraph navGraph;
        private JumpPhysics jumpPhysics;
        private KinodynamicAStar pathfinder;
        private PathResult lastResult;

        /// <summary>Чи готова система до пошуку шляху.</summary>
        public bool IsReady { get; private set; }

        /// <summary>Останній результат пошуку.</summary>
        public PathResult LastResult => lastResult;

        // =====================================================================
        //  UNITY LIFECYCLE
        // =====================================================================

        private void Start()
        {
            if (autoFindPath)
            {
                Invoke(nameof(Initialize), findPathDelay);
            }
        }

        // =====================================================================
        //  ІНІЦІАЛІЗАЦІЯ
        // =====================================================================

        /// <summary>
        /// Ініціалізує всі підсистеми та запускає пошук шляху.
        /// </summary>
        [ContextMenu("Ініціалізувати та знайти шлях")]
        public void Initialize()
        {
            // Перевірка залежностей
            if (sceneVoxelizer == null)
            {
                Debug.LogError("[NavigationManager] SceneVoxelizer не призначений!");
                return;
            }

            if (agentParameters == null)
            {
                Debug.LogError("[NavigationManager] AgentParameters не призначений!");
                return;
            }

            if (!sceneVoxelizer.IsBuilt)
            {
                Debug.LogWarning("[NavigationManager] Октодерево ще не побудовано. Чекаємо...");
                Invoke(nameof(Initialize), 0.2f);
                return;
            }

            // Створюємо JumpPhysics з тим самим LayerMask що і в SceneVoxelizer.
            // Це КРИТИЧНО: якщо маски різні, JumpPhysics не бачитиме деякі перешкоди
            // (наприклад, стінки на шарі Default), і траєкторії будуть проходити крізь них.
            LayerMask physicsLayers = sceneVoxelizer.Octree.ObstacleLayerMask;
            jumpPhysics = new JumpPhysics(agentParameters, physicsLayers);

            // Створюємо NavGraph
            navGraph = new NavGraph(sceneVoxelizer.Octree, jumpPhysics, agentParameters)
            {
                MaxSafeFallHeight = maxSafeFallHeight,
                FallFearMultiplier = fallFearMultiplier
            };
            navGraph.BuildEdges(); // Будуємо ребра ПІСЛЯ встановлення параметрів

            Debug.Log($"[NavigationManager] Навігаційний граф створено. " +
                      $"Вузлів: {navGraph.NodeCount}");

            // Створюємо A*
            pathfinder = new KinodynamicAStar(navGraph)
            {
                HeightWeight = heightWeight,
                DangerWeight = dangerWeight,
                HeuristicWeight = heuristicWeight,
                MaxIterations = maxIterations,
                MaxSearchTimeMs = maxSearchTimeMs
            };

            Debug.Log($"[NavigationManager] A* налаштований. " +
                      $"Ліміт часу: {maxSearchTimeMs} мс, Ліміт ітерацій: {maxIterations}");

            IsReady = true;

            // Автоматичний пошук шляху
            if (startPoint != null && goalPoint != null)
            {
                FindPath();
            }
        }

        // =====================================================================
        //  ПОШУК ШЛЯХУ
        // =====================================================================

        /// <summary>
        /// Запускає пошук шляху між startPoint та goalPoint.
        /// </summary>
        [ContextMenu("Знайти шлях")]
        public void FindPath()
        {
            if (!IsReady)
            {
                Debug.LogWarning("[NavigationManager] Система не готова. Викличте Initialize() спочатку.");
                return;
            }

            if (startPoint == null || goalPoint == null)
            {
                Debug.LogError("[NavigationManager] StartPoint або GoalPoint не призначені!");
                return;
            }

            lastResult = pathfinder.FindPath(startPoint.position, goalPoint.position);
            Debug.Log($"[NavigationManager] {lastResult}");
        }

        /// <summary>
        /// Пошук шляху між довільними позиціями (для виклику з коду).
        /// </summary>
        public PathResult FindPath(Vector3 from, Vector3 to)
        {
            if (!IsReady) return null;
            lastResult = pathfinder.FindPath(from, to);
            return lastResult;
        }

        // =====================================================================
        //  ВІЗУАЛІЗАЦІЯ GIZMOS
        // =====================================================================

        private void OnDrawGizmosSelected()
        {
            // === ТЕПЛОВІЗІЙНА КАРТА СТРАХУ ПАДІННЯ ===
            if (showFallFearHeatmap && navGraph != null && navGraph.EdgeProximity != null)
            {
                DrawFallFearHeatmap();
            }

            // Малюємо стартову та цільову точки
            if (startPoint != null)
            {
                Gizmos.color = startColor;
                Gizmos.DrawWireSphere(startPoint.position, 0.5f);
            }

            if (goalPoint != null)
            {
                Gizmos.color = goalColor;
                Gizmos.DrawWireSphere(goalPoint.position, 0.5f);
            }

            // Малюємо шлях
            if (!showPath || lastResult == null || !lastResult.IsSuccess) return;

            List<PathStep> steps = lastResult.Steps;

            for (int i = 0; i < steps.Count; i++)
            {
                PathStep step = steps[i];

                // Малюємо точку на кожному кроці
                Gizmos.color = GetColorForEdgeType(step.TransitionType);
                Gizmos.DrawSphere(step.Position, 0.15f);

                // Малюємо з'єднання з попереднім кроком
                if (i > 0)
                {
                    PathStep prevStep = steps[i - 1];

                    switch (step.TransitionType)
                    {
                        case EdgeType.Walk:
                            // Пряма лінія для пішохідного руху
                            Gizmos.color = walkColor;
                            Gizmos.DrawLine(prevStep.Position, step.Position);
                            break;

                        case EdgeType.Jump:
                            // Параболічна крива для стрибка
                            if (showJumpArcs && jumpPhysics != null)
                            {
                                DrawJumpArc(prevStep.Position, step.LaunchVelocity,
                                            step.FlightTime, jumpColor);
                            }
                            else
                            {
                                Gizmos.color = jumpColor;
                                Gizmos.DrawLine(prevStep.Position, step.Position);
                            }
                            break;

                        case EdgeType.Fall:
                            // Пунктирна лінія для падіння
                            Gizmos.color = fallColor;
                            DrawDashedLine(prevStep.Position, step.Position);
                            break;
                    }
                }

                // Підписи вузлів (опційно)
                if (showNodeLabels)
                {
                    #if UNITY_EDITOR
                    string label = $"{i}: {step.TransitionType}";
                    if (step.TransitionType == EdgeType.Jump)
                        label += $"\nv={step.LaunchVelocity.magnitude:F1}m/s";
                    UnityEditor.Handles.Label(step.Position + Vector3.up * 0.3f, label);
                    #endif
                }
            }
        }

        /// <summary>
        /// Малює параболічну дугу стрибка через серію коротких ліній.
        /// </summary>
        private void DrawJumpArc(Vector3 from, Vector3 launchVelocity,
                                  float flightTime, Color color)
        {
            if (jumpPhysics == null) return;

            Gizmos.color = color;
            int segments = 20;
            Vector3 prevPoint = from;

            for (int i = 1; i <= segments; i++)
            {
                float t = (float)i / segments * flightTime;
                Vector3 currentPoint = jumpPhysics.GetPositionAtTime(from, launchVelocity, t);

                Gizmos.DrawLine(prevPoint, currentPoint);
                prevPoint = currentPoint;
            }
        }

        /// <summary>
        /// Малює пунктирну лінію (для падінь).
        /// </summary>
        private void DrawDashedLine(Vector3 from, Vector3 to)
        {
            int dashes = 8;
            for (int i = 0; i < dashes; i += 2)
            {
                float t1 = (float)i / dashes;
                float t2 = (float)(i + 1) / dashes;
                Gizmos.DrawLine(
                    Vector3.Lerp(from, to, t1),
                    Vector3.Lerp(from, to, t2)
                );
            }
        }

        /// <summary>
        /// Повертає колір для типу переходу.
        /// </summary>
        private Color GetColorForEdgeType(EdgeType type)
        {
            switch (type)
            {
                case EdgeType.Walk: return walkColor;
                case EdgeType.Jump: return jumpColor;
                case EdgeType.Fall: return fallColor;
                default: return Color.white;
            }
        }

        /// <summary>
        /// Малює тепловізійну карту "страху падіння" на Ground-вокселях.
        /// 
        /// Градієнт: Зелений (0.0 = безпечний центр) → Жовтий (0.3) → Червоний (1.0 = край).
        /// Розмір куба = розмір вокселя. Малюється трохи вище поверхні, щоб не зливатися.
        /// </summary>
        private void DrawFallFearHeatmap()
        {
            var proximity = navGraph.EdgeProximity;
            if (proximity == null || proximity.Count == 0) return;

            foreach (var kv in proximity)
            {
                Navigation.Voxelization.VoxelNode node = kv.Key;
                float fear = kv.Value; // 0 = центр, 1 = край

                // Градієнт: зелений → жовтий → червоний
                Color color;
                if (fear < 0.01f)
                {
                    // Безпечний центр — зелений, напівпрозорий
                    color = new Color(0.1f, 0.8f, 0.1f, heatmapAlpha * 0.3f);
                }
                else if (fear < 0.3f)
                {
                    // Помірно безпечний — зелений → жовтий
                    float t = fear / 0.3f;
                    color = Color.Lerp(
                        new Color(0.1f, 0.8f, 0.1f, heatmapAlpha * 0.5f),
                        new Color(1f, 0.9f, 0f, heatmapAlpha * 0.7f),
                        t);
                }
                else
                {
                    // Небезпечний край — жовтий → червоний
                    float t = (fear - 0.3f) / 0.7f;
                    color = Color.Lerp(
                        new Color(1f, 0.9f, 0f, heatmapAlpha * 0.7f),
                        new Color(1f, 0.1f, 0f, heatmapAlpha),
                        t);
                }

                Gizmos.color = color;

                // Куб трохи вище поверхні і трохи менший за воксель (щоб бачити зазори)
                Vector3 drawPos = node.Center + Vector3.up * 0.05f;
                Vector3 drawSize = Vector3.one * node.Size * 0.92f;
                drawSize.y = 0.08f; // Плоский — як кольорова підкладка

                Gizmos.DrawCube(drawPos, drawSize);

                // Контур для дуже небезпечних зон
                if (fear > 0.4f)
                {
                    Gizmos.color = new Color(1f, 0f, 0f, heatmapAlpha * 0.9f);
                    Gizmos.DrawWireCube(drawPos, drawSize);
                }
            }
        }

        // =====================================================================
        //  СТАТИСТИКА (для звіту)
        // =====================================================================

        /// <summary>
        /// Виводить детальну статистику останнього пошуку.
        /// </summary>
        [ContextMenu("Показати статистику пошуку")]
        public void PrintSearchStatistics()
        {
            if (lastResult == null)
            {
                Debug.Log("[NavigationManager] Шлях ще не шукався.");
                return;
            }

            Debug.Log(
                $"=== СТАТИСТИКА ПОШУКУ A* ===\n" +
                $"Статус: {lastResult.Status}\n" +
                $"Кроків у маршруті: {lastResult.Steps?.Count ?? 0}\n" +
                $"Загальна вартість: {lastResult.TotalCost:F2}\n" +
                $"Загальна відстань: {lastResult.TotalDistance:F2} м\n" +
                $"Стрибків: {lastResult.JumpCount}\n" +
                $"Падінь: {lastResult.FallCount}\n" +
                $"Час пошуку: {lastResult.SearchTimeMs:F2} мс\n" +
                $"Ітерацій: {lastResult.IterationCount}\n" +
                $"Макс. розмір Open List: {lastResult.MaxOpenListSize}\n" +
                $"---\n" +
                $"Параметри евристики: wy={heightWeight}, w_danger={dangerWeight}, " +
                $"epsilon={heuristicWeight}\n" +
                $"Вузлів у графі: {navGraph?.NodeCount ?? 0}"
            );
        }

        /// <summary>
        /// Запускає пошук N разів і обчислює середній час (для бенчмарків).
        /// </summary>
        [ContextMenu("Бенчмарк (10 запусків)")]
        public void RunBenchmark()
        {
            if (!IsReady || startPoint == null || goalPoint == null) return;

            int runs = 10;
            float totalTime = 0f;
            int successCount = 0;

            for (int i = 0; i < runs; i++)
            {
                PathResult result = pathfinder.FindPath(startPoint.position, goalPoint.position);
                totalTime += result.SearchTimeMs;
                if (result.IsSuccess) successCount++;
            }

            Debug.Log(
                $"=== БЕНЧМАРК ({runs} запусків) ===\n" +
                $"Середній час: {totalTime / runs:F2} мс\n" +
                $"Успішних: {successCount}/{runs}\n" +
                $"Загальний час: {totalTime:F2} мс"
            );
        }
    }
}