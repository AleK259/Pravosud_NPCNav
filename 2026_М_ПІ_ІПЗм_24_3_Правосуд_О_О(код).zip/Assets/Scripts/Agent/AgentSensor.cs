using UnityEngine;

namespace Navigation.Agent
{
    /// <summary>
    /// Підсистема локального сприйняття агента (розділ 4.6 роботи).
    /// 
    /// Використовує Raycasting для:
    /// 1. Виявлення стін попереду (промені вперед).
    /// 2. Визначення краю платформи (промені вниз).
    /// 3. Перевірки безпеки приземлення (конус безпеки).
    /// 
    /// Принцип дії: R(t) = Origin + Direction · t
    /// Задача — знайти найближчу точку перетину з геометрією.
    /// </summary>
    public class AgentSensor : MonoBehaviour
    {
        [Header("Посилання")]
        [SerializeField] private AgentParameters agentParams;

        [Header("Шари")]
        [Tooltip("Шари геометрії для сканування.")]
        [SerializeField] private LayerMask groundLayers;

        [Tooltip("Шари небезпечних зон.")]
        [SerializeField] private LayerMask dangerLayers;

        [Header("Промені вперед (виявлення стін)")]
        [Tooltip("Довжина переднього променя (метри).")]
        [SerializeField] private float forwardRayLength = 2f;

        [Tooltip("Кількість променів у віялі вперед.")]
        [SerializeField] private int forwardRayCount = 3;

        [Tooltip("Кут розкидання віяла (градуси).")]
        [SerializeField] private float forwardSpreadAngle = 30f;

        [Header("Промені вниз (край платформи)")]
        [Tooltip("Довжина променя вниз.")]
        [SerializeField] private float downRayLength = 3f;

        [Tooltip("Зміщення точки старту від центру вперед.")]
        [SerializeField] private float edgeCheckForwardOffset = 0.5f;

        [Header("Конус безпеки (приземлення)")]
        [Tooltip("Кількість променів у конусі.")]
        [SerializeField] private int landingRayCount = 5;

        [Tooltip("Кут конуса (градуси від вертикалі).")]
        [SerializeField] private float landingConeAngle = 20f;

        [Tooltip("Довжина променів конуса.")]
        [SerializeField] private float landingRayLength = 4f;

        [Header("Візуалізація")]
        [SerializeField] private bool showDebugRays = true;

        // =====================================================================
        //  РЕЗУЛЬТАТИ СКАНУВАННЯ (оновлюються кожен кадр)
        // =====================================================================

        /// <summary>Чи виявлено стіну попереду.</summary>
        public bool WallAhead { get; private set; }

        /// <summary>Відстань до стіни (0 = немає стіни).</summary>
        public float WallDistance { get; private set; }

        /// <summary>Чи є агент на краю платформи.</summary>
        public bool AtEdge { get; private set; }

        /// <summary>Чи є земля безпосередньо під агентом.</summary>
        public bool GroundBelow { get; private set; }

        /// <summary>Відстань до землі під агентом.</summary>
        public float GroundDistance { get; private set; }

        /// <summary>Нормаль поверхні під агентом.</summary>
        public Vector3 GroundNormal { get; private set; }

        /// <summary>Чи безпечна поверхня для приземлення.</summary>
        public bool LandingSafe { get; private set; }

        /// <summary>Нормаль поверхні приземлення.</summary>
        public Vector3 LandingNormal { get; private set; }

        /// <summary>Чи знаходиться агент над небезпечною зоною.</summary>
        public bool DangerBelow { get; private set; }

        // =====================================================================
        //  UNITY LIFECYCLE
        // =====================================================================

        private void FixedUpdate()
        {
            ScanForward();
            ScanGround();
            ScanEdge();
        }

        /// <summary>
        /// Сканує конус безпеки (викликається окремо під час фази польоту).
        /// </summary>
        public void ScanLanding()
        {
            CheckLandingSafety();
        }

        // =====================================================================
        //  ПРОМЕНІ ВПЕРЕД (виявлення стін)
        // =====================================================================

        /// <summary>
        /// Випускає віяло променів вперед від позиції агента.
        /// Визначає наявність та відстань до стіни.
        /// </summary>
        private void ScanForward()
        {
            WallAhead = false;
            WallDistance = forwardRayLength;

            Vector3 origin = transform.position + Vector3.up * agentParams.HalfHeight;
            Vector3 forward = transform.forward;

            float halfSpread = forwardSpreadAngle * 0.5f;

            for (int i = 0; i < forwardRayCount; i++)
            {
                float angle;
                if (forwardRayCount == 1)
                    angle = 0f;
                else
                    angle = Mathf.Lerp(-halfSpread, halfSpread, (float)i / (forwardRayCount - 1));

                Vector3 direction = Quaternion.Euler(0, angle, 0) * forward;

                if (Physics.Raycast(origin, direction, out RaycastHit hit,
                                     forwardRayLength, groundLayers,
                                     QueryTriggerInteraction.Ignore))
                {
                    WallAhead = true;
                    if (hit.distance < WallDistance)
                        WallDistance = hit.distance;

                    if (showDebugRays)
                        Debug.DrawLine(origin, hit.point, Color.red);
                }
                else
                {
                    if (showDebugRays)
                        Debug.DrawRay(origin, direction * forwardRayLength, Color.green);
                }
            }
        }

        // =====================================================================
        //  ПРОМЕНІ ВНИЗ (земля під агентом)
        // =====================================================================

        /// <summary>
        /// Перевіряє наявність землі безпосередньо під агентом.
        /// Визначає відстань та нормаль поверхні.
        /// </summary>
        private void ScanGround()
        {
            float halfHeight = agentParams != null ? agentParams.HalfHeight : 0.9f;
            float radius = agentParams != null ? agentParams.radius : 0.3f;

            // SphereCast замість Raycast: сфера радіусом агента
            // покриває всю "стопу" капсули. Навіть якщо центр агента
            // висить над прірвою, але край капсули стоїть на платформі —
            // SphereCast це зловить.
            //
            //    Raycast (один промінь):     SphereCast (сфера):
            //         |                         (===)
            //         |  ← промахується         | | | ← ловить край
            //    ─────┤                    ─────┤
            //    платформа                 платформа
            //
            Vector3 origin = transform.position - Vector3.up * (halfHeight - radius - 0.1f);
            float castDistance = 0.5f; // Невелика відстань вниз

            if (Physics.SphereCast(origin, radius * 0.9f, Vector3.down,
                                    out RaycastHit hit, castDistance,
                                    groundLayers, QueryTriggerInteraction.Ignore))
            {
                GroundBelow = true;
                GroundDistance = hit.distance;
                GroundNormal = hit.normal;

                if (showDebugRays)
                    Debug.DrawLine(origin, hit.point, Color.blue);
            }
            else
            {
                GroundBelow = false;
                GroundDistance = downRayLength;
                GroundNormal = Vector3.up;

                if (showDebugRays)
                    Debug.DrawRay(origin, Vector3.down * castDistance, Color.yellow);
            }

            // Перевірка небезпечної зони (тригери — Collide)
            DangerBelow = Physics.SphereCast(origin, radius * 0.5f, Vector3.down,
                                              out RaycastHit _, castDistance,
                                              dangerLayers, QueryTriggerInteraction.Collide);
        }

        // =====================================================================
        //  ПРОМЕНІ КРАЮ ПЛАТФОРМИ
        // =====================================================================

        /// <summary>
        /// Визначає, чи стоїть агент на краю платформи.
        /// Кидає промінь вниз зі зміщенням вперед.
        /// Якщо промінь не потрапив у землю — агент на краю.
        /// </summary>
        private void ScanEdge()
        {
            Vector3 checkOrigin = transform.position
                                  + transform.forward * edgeCheckForwardOffset
                                  + Vector3.up * 0.5f;

            if (Physics.Raycast(checkOrigin, Vector3.down, downRayLength,
                                 groundLayers, QueryTriggerInteraction.Ignore))
            {
                AtEdge = false;

                if (showDebugRays)
                    Debug.DrawRay(checkOrigin, Vector3.down * 1f, Color.cyan);
            }
            else
            {
                AtEdge = true;

                if (showDebugRays)
                    Debug.DrawRay(checkOrigin, Vector3.down * downRayLength, Color.magenta);
            }
        }

        // =====================================================================
        //  КОНУС БЕЗПЕКИ (приземлення) — розділ 4.6 роботи
        // =====================================================================

        /// <summary>
        /// Конус безпеки: випускає пучок променів вниз під час фази падіння.
        /// На основі отриманих точок перетину розраховує нормаль поверхні.
        /// Якщо кут між нормаллю та вектором "вгору" перевищує критичне
        /// значення θcrit — поверхня непридатна для приземлення.
        /// </summary>
        private void CheckLandingSafety()
        {
            LandingSafe = false;
            LandingNormal = Vector3.up;

            Vector3 origin = transform.position;
            int hits = 0;
            Vector3 normalSum = Vector3.zero;
            float maxWalkAngle = agentParams.maxWalkableAngle;

            for (int i = 0; i < landingRayCount; i++)
            {
                // Розподіляємо промені у конусі навколо вертикалі
                float angle;
                Vector3 direction;

                if (i == 0)
                {
                    // Центральний промінь — прямо вниз
                    direction = Vector3.down;
                }
                else
                {
                    float t = (float)i / landingRayCount;
                    float yawAngle = t * 360f;
                    float pitchAngle = landingConeAngle;

                    direction = Quaternion.Euler(pitchAngle, yawAngle, 0) * Vector3.down;
                }

                if (Physics.Raycast(origin, direction, out RaycastHit hit,
                                     landingRayLength, groundLayers,
                                     QueryTriggerInteraction.Ignore))
                {
                    hits++;
                    normalSum += hit.normal;

                    // Перевіряємо кут нахилу кожної точки
                    angle = Vector3.Angle(hit.normal, Vector3.up);

                    if (showDebugRays)
                    {
                        Color rayColor = angle <= maxWalkAngle ? Color.green : Color.red;
                        Debug.DrawLine(origin, hit.point, rayColor);
                    }
                }
                else
                {
                    // Промінь не знайшов поверхню — під агентом прірва
                    if (showDebugRays)
                        Debug.DrawRay(origin, direction * landingRayLength, Color.red);
                }
            }

            if (hits > 0)
            {
                LandingNormal = (normalSum / hits).normalized;
                float avgAngle = Vector3.Angle(LandingNormal, Vector3.up);
                LandingSafe = avgAngle <= maxWalkAngle;
            }
        }

        // =====================================================================
        //  ПУБЛІЧНІ МЕТОДИ ДЛЯ КОНТРОЛЕРА
        // =====================================================================

        /// <summary>
        /// Перевіряє, чи безпечно стрибати зараз.
        /// Комбінує кілька сенсорів: є земля під ногами,
        /// немає стіни попереду (або є місце для стрибка).
        /// </summary>
        public bool IsJumpSafe()
        {
            return GroundBelow && !DangerBelow && GroundDistance < 0.5f;
        }

        /// <summary>
        /// Перевіряє, чи агент стоїть стабільно на поверхні.
        /// </summary>
        public bool IsGrounded()
        {
            return GroundBelow && GroundDistance < 0.3f;
        }
    }
}