using UnityEngine;

namespace Navigation.Agent
{
    /// <summary>
    /// Система "смерті" агента. Відслідковує:
    /// 1. Контакт з Danger-зоною (тригер)
    /// 2. Падіння нижче deathY (-50)
    /// 3. Час у повітрі без опори (падіння у прірву)
    /// 
    /// При "смерті" зупиняє агента і логує причину.
    /// Використовується для валідації маршрутів у бенчмарках.
    /// </summary>
    public class AgentDeath : MonoBehaviour
    {
        [Header("Параметри")]
        [Tooltip("Мінімальна висота Y. Нижче = смерть.")]
        [SerializeField] private float deathY = -50f;

        [Tooltip("Шар небезпечних зон.")]
        [SerializeField] private LayerMask dangerLayers;

        [Tooltip("Максимальний час у повітрі без опори (секунди). " +
                 "Якщо агент падає довше — вважається загиблим.")]
        [SerializeField] private float maxFallTime = 4f;

        /// <summary>Чи агент "мертвий".</summary>
        public bool IsDead { get; private set; }

        /// <summary>Причина смерті.</summary>
        public string DeathReason { get; private set; }

        /// <summary>Подія смерті (для бенчмарків).</summary>
        public System.Action<string> OnDeath;

        private AgentSensor sensor;
        private float airTime;

        private void Awake()
        {
            sensor = GetComponent<AgentSensor>();
        }

        private void FixedUpdate()
        {
            if (IsDead) return;

            // 1. Перевірка висоти
            if (transform.position.y < deathY)
            {
                Die("Падіння нижче Y=" + deathY);
                return;
            }

            // 2. Перевірка часу у повітрі
            if (sensor != null && !sensor.GroundBelow)
            {
                airTime += Time.fixedDeltaTime;
                if (airTime > maxFallTime)
                {
                    Die("Падіння у прірву (повітря > " + maxFallTime + "с)");
                    return;
                }
            }
            else
            {
                airTime = 0f;
            }
        }

        private void OnTriggerEnter(Collider other)
        {
            if (IsDead) return;

            if (((1 << other.gameObject.layer) & dangerLayers) != 0)
            {
                Die("Контакт з Danger-зоною: " + other.gameObject.name);
            }
        }

        private void OnTriggerStay(Collider other)
        {
            if (IsDead) return;

            if (((1 << other.gameObject.layer) & dangerLayers) != 0)
            {
                Die("Контакт з Danger-зоною: " + other.gameObject.name);
            }
        }

        private void Die(string reason)
        {
            IsDead = true;
            DeathReason = reason;

            Debug.LogWarning($"[AgentDeath] ЗАГИНУВ: {reason} на позиції {transform.position}");

            // Зупиняємо рух
            Rigidbody rb = GetComponent<Rigidbody>();
            if (rb != null)
            {
                rb.linearVelocity = Vector3.zero;
                rb.isKinematic = true;
            }

            // Зупиняємо NPCController
            NPCController npc = GetComponent<NPCController>();
            if (npc != null)
            {
                npc.Stop();
            }

            OnDeath?.Invoke(reason);
        }

        /// <summary>
        /// Воскрешає агента (для повторних тестів).
        /// </summary>
        public void Resurrect()
        {
            IsDead = false;
            DeathReason = null;
            airTime = 0f;

            Rigidbody rb = GetComponent<Rigidbody>();
            if (rb != null)
            {
                rb.isKinematic = false;
            }
        }

        /// <summary>
        /// Воскрешає і переміщує на задану позицію.
        /// </summary>
        public void Resurrect(Vector3 position)
        {
            Resurrect();
            transform.position = position;

            Rigidbody rb = GetComponent<Rigidbody>();
            if (rb != null)
            {
                rb.linearVelocity = Vector3.zero;
            }
        }
    }
}