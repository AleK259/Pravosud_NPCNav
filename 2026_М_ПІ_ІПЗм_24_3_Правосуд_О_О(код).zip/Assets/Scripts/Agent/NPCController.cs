using System.Collections.Generic;
using UnityEngine;
using Navigation.Agent;

namespace Navigation
{
    /// <summary>
    /// Стан кінцевого автомата NPC.
    /// </summary>
    public enum NPCState
    {
        Idle,           // Очікування маршруту
        Walking,        // Рух пішки до наступної точки
        PreparingJump,  // Зупинка на краю, підготовка стрибка
        InAir,          // У повітрі (стрибок або падіння)
        Landing,        // Приземлення, стабілізація
        Finished,       // Маршрут завершено (досягнуто цілі)
        Failed          // Помилка (впав, застряг)
    }

    /// <summary>
    /// Контролер руху NPC по знайденому маршруту.
    /// Реалізує кінцевий автомат станів:
    /// Idle → Walking → PreparingJump → InAir → Landing → Walking → ...→ Finished
    /// 
    /// Використовує Rigidbody для фізичного руху та AgentSensor
    /// для локального сприйняття (розділ 4.6 роботи).
    /// 
    /// Налаштування:
    /// 1. Створи GameObject з Capsule-колайдером та Rigidbody.
    /// 2. Додай компоненти AgentSensor та NPCController.
    /// 3. Призначь AgentParameters та NavigationManager.
    /// 4. Натисни Play — NPC автоматично рушить по маршруту.
    /// </summary>
    [RequireComponent(typeof(Rigidbody))]
    [RequireComponent(typeof(AgentSensor))]
    public class NPCController : MonoBehaviour
    {
        // =====================================================================
        //  НАЛАШТУВАННЯ
        // =====================================================================

        [Header("Посилання")]
        [SerializeField] private AgentParameters agentParams;
        [SerializeField] private NavigationManager navigationManager;

        [Header("Рух")]
        [Tooltip("Швидкість повороту до цілі (градуси/секунду).")]
        [SerializeField] private float rotationSpeed = 360f;

        [Tooltip("Відстань до waypoint, при якій вважається досягнутим.")]
        [SerializeField] private float waypointReachDistance = 0.8f;

        [Tooltip("Час затримки перед стрибком (секунди).")]
        [SerializeField] private float jumpPrepareTime = 0.05f;

        [Tooltip("Час стабілізації після приземлення (секунди).")]
        [SerializeField] private float landingStabilizeTime = 0.3f;

        [Header("Безпека")]
        [Tooltip("Максимальний час у повітрі перед аварійним скидом (секунди).")]
        [SerializeField] private float maxAirTime = 5f;

        [Tooltip("Максимальний час на один waypoint перед skip (секунди).")]
        [SerializeField] private float maxWaypointTime = 3f;

        [Header("Візуалізація")]
        [SerializeField] private bool showCurrentTarget = true;
        [SerializeField] private bool logStateChanges = true;

        // =====================================================================
        //  ВНУТРІШНІЙ СТАН
        // =====================================================================

        private Rigidbody rb;
        private AgentSensor sensor;

        private List<PathStep> path;
        private int currentStepIndex;
        private NPCState currentState;

        private float stateTimer;      // Час у поточному стані
        private float waypointTimer;   // Час на поточний waypoint
        private bool hasPath;

        // =====================================================================
        //  ПУБЛІЧНІ ВЛАСТИВОСТІ
        // =====================================================================

        /// <summary>Поточний стан автомата.</summary>
        public NPCState CurrentState => currentState;

        /// <summary>Поточний крок маршруту.</summary>
        public int CurrentStepIndex => currentStepIndex;

        /// <summary>Загальна кількість кроків.</summary>
        public int TotalSteps => path?.Count ?? 0;

        /// <summary>Чи завершив агент маршрут.</summary>
        public bool IsFinished => currentState == NPCState.Finished;

        // =====================================================================
        //  UNITY LIFECYCLE
        // =====================================================================

        private void Awake()
        {
            rb = GetComponent<Rigidbody>();
            sensor = GetComponent<AgentSensor>();

            // Налаштування Rigidbody для персонажа
            rb.freezeRotation = true;    // Не перекидатися
            rb.interpolation = RigidbodyInterpolation.Interpolate;
            rb.collisionDetectionMode = CollisionDetectionMode.Continuous;

            currentState = NPCState.Idle;
        }

        private void Start()
        {
            // Чекаємо поки навігація знайде шлях
            InvokeRepeating(nameof(TryGetPath), 0.5f, 0.5f);
        }

        private void FixedUpdate()
        {
            if (!hasPath) return;

            stateTimer += Time.fixedDeltaTime;
            waypointTimer += Time.fixedDeltaTime;

            switch (currentState)
            {
                case NPCState.Walking:
                    UpdateWalking();
                    break;
                case NPCState.PreparingJump:
                    UpdatePreparingJump();
                    break;
                case NPCState.InAir:
                    UpdateInAir();
                    break;
                case NPCState.Landing:
                    UpdateLanding();
                    break;
            }
        }

        // =====================================================================
        //  ІНІЦІАЛІЗАЦІЯ МАРШРУТУ
        // =====================================================================

        /// <summary>
        /// Спробує отримати маршрут від NavigationManager.
        /// </summary>
        private void TryGetPath()
        {
            if (hasPath) return;

            if (navigationManager == null || navigationManager.LastResult == null) return;
            if (!navigationManager.LastResult.IsSuccess) return;

            SetPath(navigationManager.LastResult);
            CancelInvoke(nameof(TryGetPath));
        }

        /// <summary>
        /// Задає маршрут для агента.
        /// Пропускає Walk-кроки, які вже поруч (агент не повинен
        /// повертатися назад до пройдених вокселів).
        /// </summary>
        public void SetPath(PathResult result)
        {
            if (result == null || !result.IsSuccess || result.Steps.Count < 2)
            {
                Debug.LogWarning("[NPC] Отримано невалідний маршрут.");
                return;
            }

            path = result.Steps;
            hasPath = true;

            // Знаходимо перший крок, до якого варто йти:
            // Пропускаємо всі Walk-кроки, що ближче за skipRadius.
            // Зупиняємося перед першим Jump/Fall (його пропускати не можна).
            float skipRadius = waypointReachDistance * 3f;
            currentStepIndex = 1;

            for (int i = 1; i < path.Count; i++)
            {
                // Ніколи не пропускаємо стрибки та падіння
                if (path[i].TransitionType == EdgeType.Jump ||
                    path[i].TransitionType == EdgeType.Fall)
                    break;

                float dist = HorizontalDistance(transform.position, path[i].Position);
                if (dist < skipRadius)
                {
                    currentStepIndex = i + 1;
                }
                else
                {
                    break; // Знайшли waypoint, до якого треба йти
                }
            }

            // Не виходимо за межі
            if (currentStepIndex >= path.Count)
                currentStepIndex = path.Count - 1;

            ChangeState(NPCState.Walking);
        }

        // =====================================================================
        //  ЗМІНА СТАНУ
        // =====================================================================

        private void ChangeState(NPCState newState)
        {
            currentState = newState;
            stateTimer = 0f;
        }

        // =====================================================================
        //  СТАН: WALKING (рух пішки)
        // =====================================================================

        private void UpdateWalking()
        {
            if (currentStepIndex >= path.Count)
            {
                ChangeState(NPCState.Finished);
                rb.linearVelocity = Vector3.zero;
                return;
            }

            PathStep target = path[currentStepIndex];

            // Перевірка таймауту
            if (waypointTimer > maxWaypointTime)
            {
                Debug.LogWarning($"[NPC] Таймаут waypoint {currentStepIndex}. Пропускаю.");
                AdvanceToNextStep();
                return;
            }

            // === СТРИБОК/ПАДІННЯ ===
            // Якщо наступний крок — стрибок, спочатку підходимо до точки відштовхування.
            // Точка відштовхування — це ПОПЕРЕДНІЙ вузол маршруту (центр вокселя,
            // звідки стрибок був розрахований). Без цього агент стрибає збоку
            // платформи після обходу перешкоди і промахується.
            if (target.TransitionType == EdgeType.Jump ||
                target.TransitionType == EdgeType.Fall)
            {
                Vector3 jumpOffPoint = (currentStepIndex > 0)
                    ? path[currentStepIndex - 1].Position
                    : transform.position;

                float distToJumpOff = HorizontalDistance(transform.position, jumpOffPoint);

                if (distToJumpOff > waypointReachDistance)
                {
                    // Ще не дійшли до точки відштовхування — рухаємось до неї
                    MoveTowards(jumpOffPoint);
                    return;
                }
                else
                {
                    // На місці — можна стрибати
                    ChangeState(NPCState.PreparingJump);
                    return;
                }
            }

            // === LOOK-AHEAD: пропускаємо Walk-кроки, повз які вже пройшли ===
            float distToCurrent = HorizontalDistance(transform.position, target.Position);

            while (currentStepIndex + 1 < path.Count)
            {
                PathStep nextStep = path[currentStepIndex + 1];

                if (nextStep.TransitionType == EdgeType.Jump ||
                    nextStep.TransitionType == EdgeType.Fall)
                    break;

                float distToNext = HorizontalDistance(transform.position, nextStep.Position);

                if (distToNext < distToCurrent && distToCurrent < waypointReachDistance * 2f)
                {
                    currentStepIndex++;
                    waypointTimer = 0f;
                    target = nextStep;
                    distToCurrent = distToNext;
                }
                else
                {
                    break;
                }
            }

            // === ПІШОХІДНИЙ РУХ ===
            if (distToCurrent < waypointReachDistance)
            {
                AdvanceToNextStep();
                return;
            }

            MoveTowards(target.Position);
        }

        /// <summary>
        /// Рухає агента горизонтально до заданої точки (поворот + рух вперед).
        /// </summary>
        private void MoveTowards(Vector3 targetPos)
        {
            Vector3 direction = targetPos - transform.position;
            direction.y = 0;

            if (direction.magnitude < 0.01f) return;

            Quaternion targetRotation = Quaternion.LookRotation(direction.normalized);
            transform.rotation = Quaternion.RotateTowards(
                transform.rotation, targetRotation,
                rotationSpeed * Time.fixedDeltaTime);

            Vector3 targetVelocity = direction.normalized * agentParams.moveSpeed;
            targetVelocity.y = rb.linearVelocity.y;
            rb.linearVelocity = targetVelocity;
        }

        // =====================================================================
        //  СТАН: PREPARING JUMP (підготовка стрибка)
        // =====================================================================

        private void UpdatePreparingJump()
        {
            // Зупиняємо горизонтальний рух
            rb.linearVelocity = new Vector3(0, rb.linearVelocity.y, 0);

            // Повертаємося до цілі стрибка
            if (currentStepIndex < path.Count)
            {
                Vector3 jumpTarget = path[currentStepIndex].Position;
                Vector3 lookDir = jumpTarget - transform.position;
                lookDir.y = 0;

                if (lookDir.sqrMagnitude > 0.01f)
                {
                    transform.rotation = Quaternion.LookRotation(lookDir.normalized);
                }
            }

            // Чекаємо на підготовку
            if (stateTimer >= jumpPrepareTime)
            {
                ExecuteJump();
            }
        }

        /// <summary>
        /// Виконує стрибок: розраховує швидкість від поточної позиції агента
        /// до цільової точки і задає її Rigidbody.
        /// Перераховує швидкість "на льоту", бо агент може бути не точно
        /// в центрі вокселя, звідки був розрахований оригінальний вектор.
        /// </summary>
        private void ExecuteJump()
        {
            if (currentStepIndex >= path.Count) return;

            PathStep step = path[currentStepIndex];

            if (step.TransitionType == EdgeType.Jump)
            {
                Vector3 from = transform.position;
                Vector3 to = step.Position;

                // Використовуємо ВЕРТИКАЛЬНУ складову з маршруту (висока дуга),
                // але коригуємо ГОРИЗОНТАЛЬНУ під фактичну позицію агента.
                // Вертикальна складова визначає висоту дуги — її розрахував CanReach
                // з урахуванням мінімальної висоти над перешкодами.
                Vector3 storedVel = step.LaunchVelocity;
                float storedVy = storedVel.y;

                // Горизонтальний напрямок від фактичної позиції до цілі
                Vector3 horizontalDir = to - from;
                horizontalDir.y = 0;
                float horizontalDist = horizontalDir.magnitude;

                if (horizontalDist < 0.01f)
                {
                    // Стрибок прямо вгору
                    rb.linearVelocity = new Vector3(0, storedVy, 0);
                }
                else
                {
                    // Горизонтальна швидкість: відстань / час
                    float flightTime = step.FlightTime;
                    Vector3 horizontalVel = horizontalDir.normalized * (horizontalDist / flightTime);

                    // Фінальна швидкість: горизонталь від позиції + вертикаль від маршруту
                    Vector3 launchVel = new Vector3(horizontalVel.x, storedVy, horizontalVel.z);

                    // Якщо занадто швидко — масштабуємо
                    if (launchVel.magnitude > agentParams.maxJumpSpeed * 1.5f)
                    {
                        launchVel = launchVel.normalized * agentParams.maxJumpSpeed;
                    }

                    rb.linearVelocity = launchVel;
                }

                jumpTargetPosition = to;
            }
            else if (step.TransitionType == EdgeType.Fall)
            {
                Vector3 fallDir = step.Position - transform.position;
                fallDir.y = 0;
                if (fallDir.magnitude > 0.01f)
                    fallDir = fallDir.normalized * agentParams.moveSpeed * 0.5f;

                rb.linearVelocity = new Vector3(fallDir.x, rb.linearVelocity.y, fallDir.z);
                jumpTargetPosition = step.Position;
            }

            ChangeState(NPCState.InAir);
        }

        // Ціль поточного стрибка (для landing assist)
        private Vector3 jumpTargetPosition;

        // =====================================================================
        //  СТАН: IN AIR (у повітрі)
        // =====================================================================

        private void UpdateInAir()
        {
            sensor.ScanLanding();

            // Аварійний таймаут
            if (stateTimer > maxAirTime)
            {
                Debug.LogWarning("[NPC] Занадто довго у повітрі! Аварійне приземлення.");
                ChangeState(NPCState.Landing);
                return;
            }

            // === LANDING ASSIST ===
            Vector3 vel = rb.linearVelocity;
            if (vel.y < 0 && stateTimer > 0.15f)
            {
                Vector3 toTarget = jumpTargetPosition - transform.position;
                toTarget.y = 0;
                float horizontalDist = toTarget.magnitude;

                if (horizontalDist < 2.0f && horizontalDist > 0.1f)
                {
                    Vector3 correction = toTarget.normalized * 2.0f;
                    vel.x = Mathf.Lerp(vel.x, correction.x, Time.fixedDeltaTime * 3f);
                    vel.z = Mathf.Lerp(vel.z, correction.z, Time.fixedDeltaTime * 3f);
                    rb.linearVelocity = vel;
                }
            }

            // Перевіряємо приземлення двома способами:
            // 1. Сенсор (промінь вниз)
            // 2. Перевірка вертикальної швидкості (якщо vy ≈ 0 і час > 0.3с — ми на чомусь стоїмо)
            bool grounded = sensor.IsGrounded() && stateTimer > 0.1f;
            bool stoppedFalling = stateTimer > 0.3f &&
                                   Mathf.Abs(rb.linearVelocity.y) < 0.5f &&
                                   sensor.GroundBelow;

            if (grounded || stoppedFalling)
            {
                ChangeState(NPCState.Landing);
            }
        }

        // Лічильник кадрів у стані Landing (для стабілізації)
        private int landingFrames;

        // =====================================================================
        //  СТАН: LANDING (приземлення)
        // =====================================================================

        private void UpdateLanding()
        {
            if (stateTimer == 0f) landingFrames = 0;
            landingFrames++;

            // Гасимо швидкість
            Vector3 vel = rb.linearVelocity;
            vel.x *= 0.85f;
            vel.y = Mathf.Min(vel.y, 0); // Не відштовхуємо вгору
            vel.z *= 0.85f;
            rb.linearVelocity = vel;

            // Підтягуємо до центру цільової платформи,
            // щоб не ковзати з краю
            Vector3 toTarget = jumpTargetPosition - transform.position;
            toTarget.y = 0;
            if (toTarget.magnitude > 0.3f && toTarget.magnitude < 3f)
            {
                Vector3 nudge = toTarget.normalized * agentParams.moveSpeed * 0.3f;
                rb.linearVelocity = new Vector3(nudge.x, rb.linearVelocity.y, nudge.z);
            }

            // Чекаємо стабілізації (мінімум 3 кадри + час)
            if (stateTimer >= landingStabilizeTime && landingFrames >= 3)
            {
                rb.linearVelocity = new Vector3(0, rb.linearVelocity.y, 0);
                AdvanceToNextStep();
                ChangeState(NPCState.Walking);
            }
        }

        // =====================================================================
        //  НАВІГАЦІЯ ПО МАРШРУТУ
        // =====================================================================

        /// <summary>
        /// Переходить до наступного кроку маршруту.
        /// </summary>
        private void AdvanceToNextStep()
        {
            currentStepIndex++;
            waypointTimer = 0f;

            if (currentStepIndex >= path.Count)
            {
                ChangeState(NPCState.Finished);
                rb.linearVelocity = Vector3.zero;
            }
        }

        // =====================================================================
        //  ДОПОМІЖНІ МЕТОДИ
        // =====================================================================

        /// <summary>
        /// Горизонтальна відстань між двома точками (ігнорує Y).
        /// </summary>
        private float HorizontalDistance(Vector3 a, Vector3 b)
        {
            float dx = a.x - b.x;
            float dz = a.z - b.z;
            return Mathf.Sqrt(dx * dx + dz * dz);
        }

        // =====================================================================
        //  ПУБЛІЧНІ МЕТОДИ
        // =====================================================================

        /// <summary>
        /// Зупиняє агента та скидає маршрут.
        /// </summary>
        public void Stop()
        {
            hasPath = false;
            path = null;
            rb.linearVelocity = Vector3.zero;
            ChangeState(NPCState.Idle);
        }

        /// <summary>
        /// Запускає пошук нового маршруту і починає рух.
        /// </summary>
        public void NavigateTo(Vector3 target)
        {
            Stop();
            PathResult result = navigationManager.FindPath(transform.position, target);
            if (result != null && result.IsSuccess)
            {
                SetPath(result);
            }
        }

        // =====================================================================
        //  ВІЗУАЛІЗАЦІЯ
        // =====================================================================

        private void OnDrawGizmosSelected()
        {
            if (!hasPath || path == null) return;

            // Поточна ціль
            if (showCurrentTarget && currentStepIndex < path.Count)
            {
                PathStep target = path[currentStepIndex];

                // Велика сфера на поточній цілі
                Gizmos.color = target.TransitionType == EdgeType.Jump
                    ? Color.yellow
                    : Color.white;
                Gizmos.DrawWireSphere(target.Position, 0.4f);

                // Лінія від агента до цілі
                Gizmos.color = Color.white;
                Gizmos.DrawLine(transform.position, target.Position);
            }

            // Весь залишок маршруту
            for (int i = currentStepIndex; i < path.Count; i++)
            {
                Gizmos.color = new Color(1, 1, 1, 0.3f);
                Gizmos.DrawSphere(path[i].Position, 0.15f);

                if (i > currentStepIndex)
                {
                    Gizmos.color = new Color(1, 1, 1, 0.2f);
                    Gizmos.DrawLine(path[i - 1].Position, path[i].Position);
                }
            }
        }
    }
}