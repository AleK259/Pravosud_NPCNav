using UnityEngine;

namespace Navigation.Agent
{
    /// <summary>
    /// Фізичні характеристики агента (NPC).
    /// Використовуються у JumpPhysics для розрахунку траєкторій,
    /// у NavGraph для визначення прохідності та в контролері руху.
    /// 
    /// Створюється як ScriptableObject, щоб можна було мати
    /// різні профілі для різних типів NPC (швидкий/повільний/сильний).
    /// </summary>
    [CreateAssetMenu(fileName = "AgentParams", menuName = "Navigation/Agent Parameters")]
    public class AgentParameters : ScriptableObject
    {
        [Header("Розміри агента")]
        [Tooltip("Радіус капсули агента (метри). Визначає ширину прохідних місць.")]
        public float radius = 0.3f;

        [Tooltip("Висота капсули агента (метри). Визначає мінімальну висоту проходу.")]
        public float height = 1.8f;

        [Header("Рух по поверхні")]
        [Tooltip("Швидкість переміщення по землі (м/с).")]
        public float moveSpeed = 5f;

        [Tooltip("Швидкість розбігу перед стрибком (м/с). " +
                 "Визначає максимальну горизонтальну складову швидкості стрибка.")]
        public float runSpeed = 7f;

        [Header("Параметри стрибка")]
        [Tooltip("Максимальна початкова швидкість стрибка (м/с). " +
                 "Це |v₀| з формули 4.3 роботи.")]
        public float maxJumpSpeed = 10f;

        [Tooltip("Максимальна вертикальна складова швидкості стрибка (м/с). " +
                 "Обмежує висоту стрибка.")]
        public float maxJumpVerticalSpeed = 8f;

        [Tooltip("Максимальний кут нахилу поверхні (градуси), " +
                 "на якій агент може стояти. Це αmax з постановки задачі (розділ 3.2).")]
        public float maxWalkableAngle = 45f;

        [Header("Фізика")]
        [Tooltip("Прискорення вільного падіння (м/с²). " +
                 "Стандартне значення Unity/PhysX = 9.81.")]
        public float gravity = 9.81f;

        [Tooltip("Маса агента (кг). Впливає на інерцію.")]
        public float mass = 70f;

        // =====================================================================
        //  ОБЧИСЛЮВАНІ ВЛАСТИВОСТІ
        // =====================================================================

        /// <summary>
        /// Максимальна висота стрибка (метри).
        /// Формула: h = v²_y / (2g)
        /// </summary>
        public float MaxJumpHeight => (maxJumpVerticalSpeed * maxJumpVerticalSpeed) / (2f * gravity);

        /// <summary>
        /// Максимальна дальність стрибка по горизонталі (метри).
        /// Для стрибка з місця під оптимальним кутом 45°.
        /// Формула: d = v² / g
        /// </summary>
        public float MaxJumpDistance => (maxJumpSpeed * maxJumpSpeed) / gravity;

        /// <summary>
        /// Максимальний час перебування у повітрі (секунди).
        /// Для вертикального стрибка: t = 2 * v_y / g
        /// </summary>
        public float MaxAirTime => (2f * maxJumpVerticalSpeed) / gravity;

        /// <summary>
        /// Вектор гравітації для фізичних розрахунків.
        /// </summary>
        public Vector3 GravityVector => new Vector3(0f, -gravity, 0f);

        /// <summary>
        /// Половина висоти капсули (для фізичних перевірок).
        /// </summary>
        public float HalfHeight => height * 0.5f;
    }
}
